
import csnd.*;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

  public class SliderDemo extends JFrame
  {
	public static void main(String[] args)
	{
		try
			{
			UIManager.setLookAndFeel(
			UIManager.getSystemLookAndFeelClassName());
			}catch (Exception e){}

			SliderDemo app = new SliderDemo();
			app.setResizable(false);

			app.addWindowListener(
				new WindowAdapter()
				{
					public void windwoClosing(WindowEvent e)
					{
						System.exit(0);
					}
				}
			);

			app.pack();
			app.setVisible(true);
	}

//******************************************************
//constructor
//******************************************************
		public SliderDemo()
		{

		super("SliderDemo");
		String title = " Slider Ex";
		setTitle(title);

		Container contentPane = getContentPane();
		contentPane.setLayout (new BoxLayout(contentPane,BoxLayout.X_AXIS));

		//uses nested boxlayout, see below
		Panel myPanel = new Panel();
		contentPane.add(myPanel);

		pack();

		args.Append("csound");
		args.Append("-s");
		args.Append("-d");
		args.Append("-odevaudio");
		args.Append("-b4096");
		args.Append("-B4096");
		//you need to add your own rtaudio device
		//and path to the SliderDemo.csd, below
		args.Append("-+rtaudio=portaudio");
		String csd ="C:/eclipse/workspace_J_Csound/SliderDemo/SliderDemo.csd";
		args.Append(csd);

		result = csound.Compile(args.argc(), args.argv());

		}
//	******************************************************
//	classes needed to implement a NESTED BOX LAYOUT
//  the contentPane.add above add the classes below
//  which add the separate classes in vertical boxlayout
//	******************************************************
	class Panel extends JPanel
	{
		public Panel()
		{
			setLayout (new BoxLayout(this,BoxLayout.Y_AXIS));
			//column 1 of the container
			StartStopPanel panel_1 = new StartStopPanel();
			add(panel_1);

			PitchSliderPanel panel_2 = new PitchSliderPanel();
			add(panel_2);

		}
	}

//******************************************************
//******************************************************
//
//		GUI JPanel Classes
//
//******************************************************
//******************************************************

//***class StartStopPanel************************************
	class StartStopPanel extends JPanel
	{
		public StartStopPanel()
		{
			//create Layout with 2 rows and 2 columns
			setLayout (new GridLayout(2,2));
			setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));

			Start = new JButton("Start");
			Start.setBackground(Color.lightGray);
			Start.setForeground(Color.black);
			Start.addActionListener(
			new StartActionListener());
			add(Start);

			Stop = new JButton("Stop");
			Stop.setBackground(Color.lightGray);
			Stop.setForeground(Color.black);
			Stop.addActionListener(
			new StopActionListener());
			add(Stop);

			Text = new JLabel("  Press Start,  then move Slider.");
			Text.setHorizontalAlignment(JLabel.LEFT);
			Text.setForeground(Color.blue);
			add(Text);
			setFont(new Font("Serif", Font.BOLD, 16));

		}
	}
//	***class PitchSliderPanel************************************
	class PitchSliderPanel extends JPanel
		{
			public PitchSliderPanel()
			{
				setLayout (new GridBagLayout());
				GridBagConstraints c = new GridBagConstraints();
				c.fill = GridBagConstraints.NONE;

				setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));

				Pitch = new JLabel("Pitch");
				Pitch.setForeground(Color.red);
				setFont(new Font("Serif", Font.BOLD, 16));
				c.weightx = 0.5;
				c.gridx = 0;
				c.gridy = 0;
				add(Pitch, c);

				//Create the slider
				PitchSlider = new JSlider(JSlider.HORIZONTAL, 0, 2000, 200);
				PitchSlider.addChangeListener(new PitchSliderChangeListener());
				PitchSlider.setMajorTickSpacing(500);
				PitchSlider.setMinorTickSpacing(1);
				PitchSlider.setPaintTicks(true);
				PitchSlider.setPaintLabels(true);
				PitchSlider.setSnapToTicks(true);
				c.weightx = 0.5;
				c.gridx = 0;
				c.gridy = 1;
				add(PitchSlider, c);
			}
		}
//******************************************************
//******************************************************
// StartStop Panel ActionListeners
//******************************************************
//	******************************************************
	private class StartActionListener implements ActionListener
		{
			public void actionPerformed(ActionEvent e)
			{

				//play button starts a csound thread
				//so you can move the slider
				if (result == 0){

					 if (!PitchSlider.getValueIsAdjusting())
					 {
						 StartPitchNum = (int)PitchSlider.getValue();
					 }

					mythread.Play();
					
					if(csnd.csoundGetChannelPtr(mycsound, myptr, "pitch",		
		csndConstants.CSOUND_INPUT_CHANNEL | csndConstants.CSOUND_CONTROL_CHANNEL ) == 0)
			csound.SetChannel("pitch" , (double)StartPitchNum);

				}
			}
		}
//	******************************************************
	private class StopActionListener implements ActionListener
		{
			public void actionPerformed(ActionEvent e)
			{
			   	mythread.Stop();
			   	csound.Reset();
			   	args.Clear();
			   	System.exit(0);

			}
		}
//	******************************************************
//	******************************************************
//   Slider Change Listener
	private class PitchSliderChangeListener implements ChangeListener
	{
		public void stateChanged(ChangeEvent e)
		{

			JSlider source = (JSlider)e.getSource();
			 if (source.getValueIsAdjusting())
			 {
				 PitchNum = (int)source.getValue();
				 if (PitchNum == 0)
				 {
					System.out.println("0");
				 }
				 else
				 {
				if (result == 0){if(csnd.csoundGetChannelPtr(mycsound, myptr, "pitch", csndConstants.CSOUND_INPUT_CHANNEL | csndConstants.CSOUND_CONTROL_CHANNEL ) == 0)	
				//myfltarray.SetValue(0, 				(double)PitchNum);
				csound.SetChannel("pitch" , 				(double)PitchNum);
				}
				//System.out.println(PitchNum);
				 }
			 }
		}
	}
//	******************************************************
//	******************************************************
//
//		  The DISPLAY ERROR Classes
//
//	******************************************************
//	******************************************************
	public static void displayError(String errMsg, Component parent)
	{
		displayError(parent,errMsg);
	}

//******************************************************
	public static void displayError( Component parent, String errMsg)
	{
		String  title="Error!";
		JOptionPane.showMessageDialog(parent,errMsg,title,
			JOptionPane.ERROR_MESSAGE);

	} //ends displayError

//******************************************************
//******************************************************
//
//		VARIABLE Definitions
//
//******************************************************
//******************************************************

	private JLabel 		Pitch;
	private JButton		Start;
	private JButton		Stop;
	private JSlider		PitchSlider;
	private JLabel		Text;

	int 		result;
	int		PitchNum;
	int 		StartPitchNum;

	Csound csound = new Csound();
        CsoundArgVList args = new CsoundArgVList();
	CsoundMYFLTArray myfltarray = new CsoundMYFLTArray();
	CsoundPerformanceThread mythread = new CsoundPerformanceThread(csound);
	SWIGTYPE_p_void myvoid;
	SWIGTYPE_p_CSOUND_ mycsound = csnd.csoundCreate(myvoid);
	SWIGTYPE_p_p_float myptr = myfltarray.GetPtr();
	
  }//end





