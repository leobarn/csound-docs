package chnget;

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 *
 * @author JCH
 */
public class StartUp extends JFrame{
	
MyJPanel myjpanel;

// ****the Container****
static Container contentPane;

    /** Creates a new instance of StartUp */
    public StartUp() {
		super("changet");
		initGUI();
    }
    
    public void initGUI(){
    	
    	myjpanel = new MyJPanel();
    	contentPane = getContentPane();
    	contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
	    contentPane.setBackground(Color.LIGHT_GRAY);
		try {
			contentPane.add(myjpanel);
		} catch (Exception e) {
		}
		
    }

    public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		}		
		StartUp app = new StartUp();
		app.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

		app.pack();
		app.setVisible(true);
    }  //ends main
    
}  //ends outer class StartUp