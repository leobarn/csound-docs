package chnget;

import csnd.*;

public class changet_thread extends Thread {

    SWIGTYPE_p_void myvoid;
    SWIGTYPE_p_CSOUND_ mycsound = csnd.csoundCreate(myvoid);
    Csound csound = new Csound();
    CsoundArgVList args = new CsoundArgVList();
    CsoundMYFLTArray myfltarray = new CsoundMYFLTArray();
    boolean on = false;
    boolean pause = false;
    double myvalue;

    changet_thread(double someValue) {
        myvalue = someValue;
        run();
    } //ends constructor

    public void run() {

        args.Append("csound");
        args.Append("-s");
        args.Append("-d");
        args.Append("-odevaudio");
        args.Append("-b4096");
        args.Append("-B4096");
        args.Append("-+rtaudio=ALSA");
        String csd = "/home/JCH/ChnGetTest.csd";
        args.Append(csd);
        try {

            int result = csound.Compile(args.argc(), args.argv());
            int myinputch = csndConstants.CSOUND_INPUT_CHANNEL;
            int mycontch = csndConstants.CSOUND_CONTROL_CHANNEL;
            SWIGTYPE_p_p_float myptr = myfltarray.GetPtr();

            if (result == 0) {
                while (csound.PerformKsmps() == 0) {
                    if (csnd.csoundGetChannelPtr(mycsound, myptr, "pitch", myinputch | mycontch) == 0) //int index, double value
                    {
                        csound.SetChannel("pitch" , myvalue);
                    }
                }
            }

        } catch (Exception e) {
        }
        //java.lang.System.err.println("Could not Perform...\n");
        //csound.Stop();
        //csound.Cleanup();
        csound.Reset();
        java.lang.System.exit(1);

    } //end run method
}//ends ChnPtr_Chnget_Thread


