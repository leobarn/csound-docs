#!/usr/bin/python
# -*- coding: latin-1 -*-

""" 
Constants for the barebones system

@author: �yvind Brandtsegg
@contact: obrandts@gmail.com
@license: GPL
"""

# composition module constants
START = 1
CONTINUE = 0
STOP = -1