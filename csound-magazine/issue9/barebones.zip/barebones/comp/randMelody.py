#!/usr/bin/python
# -*- coding: latin-1 -*-

""" 
RandMelody.

A test composition module, as a simple example of to use the software architecture "barebones".

@author: �yvind Brandtsegg
@contact: obrandts@gmail.com
@license: GPL
"""

import copy
import random
import baseComp
from constants import *

class RandMelody(baseComp.BaseComp):
    """
    A simple test composition module. Generates melodies with limited random selection of pitch, delta, duration.
    """

    def __init__(self, eventCaller=''):
        """
        Class contructor.
        
        @param self: The object pointer.
        """
        self.eventCaller = eventCaller
        """Pointer to the event caller."""
        self.isPlaying = False
        """A flag indicating if the melody should continue playing or not."""
        self.pitches = [60,62,64,65,67,69,71,72] 
        """The collection of pitches to select from."""
        self.deltaTimes = [1,2]
        """The collection of (relative) delta times to select from."""
        self.durations = [1,0.8,0.3]
        """The collection of (relative) durations to select from."""
        self.pan = 0.5
        """The stereo pan value."""
        self.reverb = 0.2
        """The reverb send value."""
        self.instrument = 1
        """The csound instrument for playback of events."""


    def getData(self):
        """
        Generate pitch, duration and delta time for the next note in the melody.
        
        @param self: The object pointer.
        @return: Parameters for the note event.
            - instrument: The csound instrument for playback of the note event.
            - amp: The amp of the note, in decibel (dbfs)
            - pitch: The pitch of the note, in note number format.
            - delta: Delta time, the time until the next event after this one. The value is relative to the current tempo so that a value of 1 equals one beat.
            - duration: The duration of the note, relative to the delta time (so that a duration of 1 generates a legato note).
            - pan: The stereo pan position of the note. A value of 0.0 is hard left, 0.5 is center, 1.0 is hard right.
            - reverb: The reverb send amount for the note, in the range 0.0 to 1.0.
        """
        pitch = self.pitches[int(random.random()*len(self.pitches))]
        delta = self.deltaTimes[int(random.random()*len(self.deltaTimes))]
        duration = self.durations[int(random.random()*len(self.durations))]
        amp = -10
        return self.instrument, amp, pitch, delta, duration, self.pan, self.reverb


    def setParameter(self, parameter, value):
        """
        Set a class variable.
        
        @param self: The object pointer.
        @param parameter: The variable name.
        @param value: The value to set the variable to.
        """
        if parameter == 'pitches': self.pitches = value
        elif parameter == 'deltaTimes': self.deltaTimes = value
        elif parameter == 'durations': self.durations = value
        elif parameter == 'pan': self.pan = value
        elif parameter == 'reverb': self.reverb = value
        elif parameter == 'instrument': self.instrument = value
        else: print 'randMelody: parameter named'%parameter


if __name__ == '__main__':
    r = RandMelody()
    """Instance of the composition class."""
    print r.getData()
    print r.getData()
    print r.getData()
