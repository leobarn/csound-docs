#!/usr/bin/python
# -*- coding: latin-1 -*-

""" 
This is a copy of the file constants.py in the root directory of barebones, used only for testing the composition modules as main.

@author: �yvind Brandtsegg
@contact: obrandts@gmail.com
@license: GPL
"""

# composition module constants
START = 1
CONTINUE = 0
STOP = -1