#!/usr/bin/python
# -*- coding: latin-1 -*-

""" 
BaseComp.

A base composition module, custom composition modules should inherit from this class.

@author: �yvind Brandtsegg
@contact: obrandts@gmail.com
@license: GPL
"""

from constants import *

class BaseComp:
    """
    A simple test composition module. Generates melodies with limited random selection of pitch, delta, duration.
    """

    def __init__(self):
        """
        Class contructor.
        
        @param self: The object pointer.
        """
        
        self.isPlaying = False
        """A flag indicating if the composition process should continue playing or not."""
        self.eventCaller = eventCaller
        """Pointer to the event caller."""

    def perform(self, state=CONTINUE, beat=0):
        """
        Handle the starting stopping or continuing of the composition process.
        
        @param self: The object pointer.
        @param state: The playback state, can be START, CONTINUE, STOP
        @param beat: The current beat count of the timed queue (self.eventCaller.theTime), may be fractional. This parameter is optional; if it is not supplied, the current beat count (integer) will be polled from theTime.
        """
        if beat == 0: beat = self.eventCaller.theTime.getCurrentBeat()
        if state == START: # does nothing but put a randMelody event in the timed queue
            if self.isPlaying != True:
                self.eventCaller.theTime.insertQueue(beat+1, [self.perform])
                self.isPlaying = True
        elif state == CONTINUE: # play a note and put a randMelody event in the timed queue
            if self.isPlaying: 
                delta = self.playEvent()
                self.eventCaller.theTime.insertQueue(beat+delta, [self.perform])
        elif state == STOP: # stop playing and remove any pending events for this instance of randMelody
            self.isPlaying = False
            for event in self.eventCaller.theTime.getQueue():
                if [self.perform] == event[1]:
                    self.eventCaller.theTime.removeEvent(event)

    def playEvent(self):
        """
        Get event data from composition method, play event to Csound, insert "next" event in theTime queue.
        
        @param self: The object pointer.
        """
        instrument, amp, pitch, delta, duration, pan, reverb = self.getData()
        duration = duration * (60.0/self.eventCaller.theTime.bpm)
        self.eventCaller.csMessages.csoundInputMessage('i %i 0 %f %f %i %f %f'%(instrument, duration, amp, pitch, pan, reverb))
        return delta
        
    def getData(self):
        """
        Get parameter values for the next event in the composition. You should override this method with something useful.
        
        @param self: The object pointer.
        """
        return 1,2,3,4,5,6,7
        
        