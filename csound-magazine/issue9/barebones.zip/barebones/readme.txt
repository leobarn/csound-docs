A barebones python/csound setup for realtime algorithmic composition
Oeyvind Brandtsegg 2008 - obrandts@gmail.com
Author's web site: http://oeyvind.teks.no/

An introduction to the barebones system can be found in the Csound Journal Issue 9 (at http://www.csounds.com/journal/).

System requirements:
Python 2.5
Csound 5.08


To start the system, run:
python main.py

Then test these commands:
perform(rMelody1, START) 
setParameter(rMelody, �pitches�, [73,74,75,76])
setParameter(rMelody, �pitches�, [60,63,65,67])
perform(rMelody1, STOP) 

To exit, type:
stop

