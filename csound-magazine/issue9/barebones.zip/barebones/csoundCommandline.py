csoundCommandline = "csound -b2000 -B4000 -d -odac3 -iadc3 -m0 -+rtaudio=pa --expression-opt temp.orc temp.sco" # internal sound card
"""The Csound commandline, setting options for audio i/o and buffers."""

