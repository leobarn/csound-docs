#!/usr/bin/python
# -*- coding: latin-1 -*-

""" 
Everything related to csound in this module.

@author: �yvind Brandtsegg
@contact: obrandts@gmail.com
@license: GPL
"""
