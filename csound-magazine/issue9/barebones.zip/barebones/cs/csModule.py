#!/usr/bin/python
# -*- coding: latin-1 -*-

""" 
A separate thread which keeps Csound output going.

@author: �yvind Brandtsegg
@contact: obrandts@gmail.com
@license: GPL
@requires: threading
"""

import csnd
import csoundCommandline
import threading
import time

class CsoundThreadRoutine:

    def __init__(self, theTime):
        """
        Class constructor.
        
        @param self: The object pointer.
        """

        self.isRunning = True
        """A flag that keeps the thread running, can be deleted when we start using csnd.PerformanceThread properly"""    

        # Create an instance of CppSound, set orchestra and score
        self.csound = csnd.CppSound()
        self.csound.setOrchestra('''#include "simple.orc" ''')
        self.csound.setScore('''#include "simple.sco" ''')

        self.csound.setCommand(csoundCommandline.csoundCommandline)
        """The Csound commandline read from file "csoundCommandLine.py", setting options for audio i/o and buffers."""
        print 'commandline', csoundCommandline.csoundCommandline

        # Export the orc and sco, compile.
        self.csound.exportForPerformance()
        self.csound.compile()

        #self.performanceThread = csnd.CsoundPerformanceThread(self.csound)
        """The C++ csound performance thread"""
        
        self.theTime = theTime
        """Pointer to the precise timed queue."""
        self.theTime.setTimePerKperiod(self.csound.GetKr())
        """Set control rate for the timed queue clock."""

        self.csoundThread = threading.Thread(None, self.csoundThreadRoutine)
        """The csoundThreadRoutine is run in it's own thread"""

        #self.callbackdata = ''
        #self.performanceThread.SetProcessCallback(self.callback, self.callbackdata)
                    
    def csoundThreadRoutine(self):
        """
        Start the performanceThread, a C++ thread for running csound, independent from the Python GIL.
        
        @param self: The object pointer.
        """
        #self.performanceThread.Play()
        
        # until I can work with callbacks , I need to do this the old way, with performKsmps
        while self.isRunning:
            self.csound.PerformKsmps()
            self.theTime.doKsmpsTick()
            time.sleep(0)
        
    def stop(self):
        """
        Terminate the csound performanceThread.
        
        @param self: The object pointer.
        """
        self.isRunning = False
        print 'stopping csound'        
        #self.performanceThread.Stop()
        #self.performanceThread.Join()
        time.sleep(1)
        # Clean up after ourselves.
        self.csound.Reset()
        self.csound.Cleanup()
