#!/usr/bin/python
# -*- coding: latin-1 -*-

""" 
The module for (accurate) timed automation.

Inherits thread safe queue handling from theTime.py, the relaxed timer.
This timer module is coupled to the csound control rate to provide more accurate timing than what is provided within standard python.

@author: �yvind Brandtsegg
@contact: obrandts@gmail.com
@license: GPL
"""

import control.theTime
import time
import bisect
import mutex
import copy

class TheTime2(control.theTime.TheTime):
    """
    The class containing accurate timer and timed queue methods.
    
    Thread safe queue handling is inherited from theTime.py.
    Automation is executed via a queue of events to be executed in time, format for the  queue is a list of events, 
    with each event represented as a list with the following format: [type, time, data]. 
    The type field is a string, to be parsed in eventCaller.parseEvents(). Time is in beats and may be fractional.
    The data field may contain several parameters (not as sublist).
    """
     
    def __init__(self, eventCaller, bpm=60):
        """
        The class constructor.
        
        @param self: The object pointer.
        @param eventCaller: A pointer to the eventCaller object.
        @param bpm: The beats per minute for the beat counter. Default = 60.
        """
        self.queueMutex = mutex.mutex()
        """The mutex for thread safe handling of the queue list."""
        self.queueMutex.testandset()
        self.eventCaller = eventCaller
        #self.timeResolution = 0.001 
        self.queue = []
        """The list of events in the timed queue."""
        self.beatCounter = 0 
        """Counter for quarter notes at a given bpm."""
        self.prevBeat = 0
        self.fractionalBeat = 0.0 
        """Counter for fractions of a beat."""
        self.bpm = bpm 
        """The tempo in beats per minute for the beat counter."""
        self.runClock = 0
        """Flag to run or pause the clock."""
        self.csoundKr = 441 
        """Csound control rate, value will be set by csound at (csound) init."""
        self.timePerKperiod = 1.0/self.csoundKr
        self.beatIncrement = (self.bpm/60.0)*self.timePerKperiod
        
    def doKsmpsTick(self):
        """
        The main clock increment method, called from csound every ksmps period, also polling the event queue.
        
        @param self: The object pointer.
        """
        nextBeatTime = 0
        if self.runClock == 1:
            
            # unlock muex, processing any insertion or deletion of events from queue
            #print 'theTime running', self.queueMutex.test()
            while self.queueMutex.test():
                self.queueMutex.unlock()
                            
            self.fractionalBeat += self.beatIncrement
            if self.fractionalBeat >= 1.0:
                self.beatCounter += 1
                #print self.beatCounter, self.fractionalBeat, self.bpm, self.beatIncrement
                self.fractionalBeat = 0                
            # check queue here, execute pending events in queue,
            #print 'theTime', self.beatCounter, self.fractionalBeat
            if self.queue != []:
                self.checkQueue(self.beatCounter+self.fractionalBeat)

    def setBpm(self, bpm):
        """
        Set the clock tempo in beats per minute.
        
        @param self: The object pointer.
        """
        self.bpm = bpm
        self.beatIncrement = (self.bpm/60.0)*self.timePerKperiod
        
    def setTimePerKperiod(self, kr):
        """
        Set the time per control rate tick from csound.
        
        @param self: The object pointer.
        @param kr: The csound control rate
        """
        print 'setTimePerKperiod', kr
        self.csoundKr = kr 
        self.timePerKperiod = 1.0/kr
        self.beatIncrement = (self.bpm/60.0)*self.timePerKperiod
        


