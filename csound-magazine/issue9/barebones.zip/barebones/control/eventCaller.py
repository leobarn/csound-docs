#!/usr/bin/python
# -*- coding: latin-1 -*-

""" 
Handles all communication between different parts of the barebones system.

@author: �yvind Brandtsegg
@contact: obrandts@gmail.com
@license: GPL
@requires: Pyro
"""

import time
import sys
import threading
import control.theTime
import comp.randMelody 
import comp.serialMelody 
from constants import *

class EventCaller:
    """
    The central control and communitation module
    
    All events from the user interface(s) are sent here. 
    All events from the timed queue are processed here. EventCaller also communicates with the compositional logic, 
    and with Csound through cs.messages. 
    """
    
    def __init__(self):
        """
        ## Class constructor.
        #
        #  @param self: The object pointer.
        """

        self.csMessages = ''
        """Pointer to csMessages instance."""
    
        self.rMelody1 = comp.randMelody.RandMelody(self)
        """Instance of the RandMelody composition class."""                
        self.rMelody2 = comp.randMelody.RandMelody(self)
        """Instance of the RandMelody composition class."""                

        self.sMelody1 = comp.serialMelody.SerialMelody(self)
        """Instance of the SerialMelody composition class."""                

        self.theTimeSeconds = control.theTime.TheTime(self, 60) 
        """Instance of a relaxed timed queue used for slow automation (seconds, minutes, hours)."""
        self.theTime = self.theTimeSeconds#''
        """Pointer to a precise timed queue, clock slaved to Csound control rate."""
        
    ####################################################################################################################
    ### Initialization methods
    ####################################################################################################################

    def initValues(self):
        """
        Initialize the system.
        
        This includes setting various initial values and instantiating csound instruments as needed for normal operation.
        
        @param self: The object pointer.
        """
        # start always on instruments in Csound
        scoreLength = 600000 # 
        self.csMessages.csoundInputMessage('i 98 0 %i'%scoreLength)    # reverb instr
        self.csMessages.csoundInputMessage('i 99 0 %i'%scoreLength)    # master audio out instr

    ####################################################################################################################
    ### Composition process methods
    ####################################################################################################################

    def perform(self, module, state):
        """
        Wrapper for (any) composition module's perform method.

        @param self: The object pointer.
        @param module: The composition module to perform.
        """
        func = 'self.%s.perform(%i)'%(module, state)
        c = compile(func, 'string', 'exec')
        exec(c)

    def setParameter(self, module, parameter, value):
        """
        Set a parameter for a composition module.
        
        @param self: The object pointer.
        @param module: The composition module to set a parameter value for.
        @param parameter: The parameter name.
        @param value: The value to set the parameter to.
        """
        print 'setParameter', module, parameter, value
        func = 'self.%s.setParameter(%s, %s)'%(module, parameter, value)
        c = compile(func, 'string', 'exec')
        exec(c)

    ####################################################################################################################
    ### Timed Queue related methods
    ####################################################################################################################
        
    def parseEvent(self, event):
        """
        Parsing of events output from queue, called from theTime.
        
        @param self: The object pointer.
        @param event: The event to be parsed.
        """
        #print 'parseEvent', event
        beat = event[0]
        try:
            event[1][0]()
        except:
            print '*** WARNING ***, timed event not recognized by eventCaller.parseEvent'
            print '...or, maybe your composition module contains a bug preventing it from being run correctly: see below...'
            print event
            print 'exception', sys.exc_info()
            #note: may have parsing of other event types here (non-code-objects)
            
         
    def startStopClock(self, state, offset=1):
        """
        Start or stop the timed queue clock
        
        @param self: The object pointer.
        @param state: The state (1 or 0) for the clock. Clock runs while state is 1, pause when state is 0.
        """  
        self.theTime.startStopClock(state, offset)

    ####################################################################################################################
    ### Various 'System' methods
    ####################################################################################################################

    def setTimeBpm(self, bpm):
        """
        Set tempo in bpm for the variable-tempo timed queue.
        
        @param self: The object pointer.
        @param bpm: The tempo in bpm.
        """
        print 'theTime tempo set to ', bpm
        self.theTime.setBpm(bpm)

    def startThreads(self):
        """
        Start timed queue (sequencer) threads.
        
        @param self: The object pointer.
        """
        self.theTimeSeconds.start()
        self.theTimeSeconds.startStopClock(1)        
        
    def stopThreads(self):
        """
        Stop timed queue (sequencer) threads.
        
        @param self: The object pointer.
        """
        self.theTimeSeconds.stop()

    def setPointers(self, csMessages, theTime):
        """
        Set pointers to other modules in the system.

        @param self: The object pointer.
        @param csMessages: Pointer to the csMessages object.
        @param theTime: Pointer to the theTime object
        """
        self.csMessages = csMessages
        self.theTime = theTime 

    def recordAudio(self, state, name="demofile.wav"):
        """
        Make an audio recording of a realtime session.
        
        @param self: The object pointer.
        @param state: START to start recording, STOP to stop.
        @param name: The file name to record audio to.
        """
        if name.find('.wav') < 0:
            print 'filename must end with .wav, record aborted'
            return
        if state == START:
            self.csMessages.csoundInputMessage('i 100 0 -1 "%s"'%name)
        else:
            self.csMessages.csoundInputMessage('i -100 0 1')
            self.csMessages.csoundInputMessage('i 101 0 1')
