#!/usr/bin/python
# -*- coding: latin-1 -*-

""" 
The module for (relaxed) timed automation.

This timer module is based on the stardard python time.sleep() and may not be 100% accurate.
For a lot of purposes however, the timing accuracy is sufficient, e.g. automation on a "per minute basis".

@author: �yvind Brandtsegg
@contact: obrandts@gmail.com
@license: GPL
"""

import threading
#import thread
import time
import bisect
import mutex


class TheTime(threading.Thread):
    """
    The class containing timer and timed queue methods.
    
    Automation is executed via a queue of events to be executed in time, format for the  queue is a list of events, 
    with each event represented as a list with the following format: [type, time, data]. 
    The type field is a string, to be parsed in eventCaller.parseEvents(). Time is in beats and may be fractional.
    The data field may contain several parameters (not as sublist).
    """

    def __init__(self, eventCaller, bpm=60):
        """
        The class constructor.
        
        Under normal operation this timer instance is a standard seconds and minutes clock so the bpm should not be changed.
        
        @param self: The object pointer.
        @param eventCaller: A pointer to the eventCaller object.
        @param bpm: The beats per minute for the beat counter. Default = 60, this should not be modified in normal cicumstances.
        """
        threading.Thread.__init__(self)
        self.eventCaller = eventCaller
        self.queueMutex = mutex.mutex()
        """The mutex for thread safe handling of the queue list."""
        self.queueMutex.testandset()
        self.isRunning = True
        """Flag to keep the clock thread running, set to False to exit thread."""
        self.timeResolution = 0.001 
        """Timer resolution in seconds, 0.001=millisecond resolution (not accurate)."""
        self.queue = []
        """The list of events in the timed queue."""
        self.beatCounter = 0 
        """Counter for quarter notes at a given bpm."""
        self.fractionalBeat = 0.0 
        """Counter for fractions of a beat."""
        self.bpm = bpm 
        """The tempo in beats per minute for the beat counter."""
        self.timeNow = 0 
        self.timeAtStart = time.clock()
        self.runClock = 0
        """Flag to run or pause the clock."""
        self.prevTime = 0
        
    def run(self):
        """
        The main clock increment method, also polling the event queue.
        
        @param self: The object pointer.
        """
        nextBeatTime = 0
        
        # Execute this loop as long as self.isRunning == True
        while (self.isRunning):
            if self.runClock == 1:

                # unlock muex, processing any insertion or deletion of events from queue
                while self.queueMutex.test():
                    self.queueMutex.unlock()

                # check current time
                timePerBeat = 60.0 / self.bpm
                self.timeNow = time.clock()
                # update beat counter
                if self.timeNow >= nextBeatTime:
                    self.beatCounter += 1
                    self.fractionalBeat = 0
                    nextBeatTime = self.timeNow + timePerBeat
                # check queue here, execute pending events in queue,
                if self.queue != []:
                    self.checkQueue(self.beatCounter+self.fractionalBeat)
                # update the fractional beat counter
                if self.timeNow >= self.prevTime + self.timeResolution:
                    self.fractionalBeat += ((self.timeNow-self.prevTime)/timePerBeat)
                    #if self.fractionalBeat > 1.0 - self.timeResolution: self.fractionalBeat = 1.0 - self.timeResolution
                    #print 'beat', self.beatCounter+self.fractionalBeat
                    self.prevTime = self.timeNow
            time.sleep(self.timeResolution) # millisecond resolution

    def startStopClock(self, state, offset=1):
        """
        Start or stop (pause) the clock.
        
        An optional offset may increment the current beat count when starting the clock.
        
        @param self: The object pointer.
        @param state: The running state (True or False) of the clock.
        @param offset: The beat offset to be used for incrementing the beat counter when starting the clock.
        """
        if state: # increment beat counter with offset when starting clock
            self.beatCounter += offset
            self.fractionalBeat = 0
            self.prevTime = time.clock()
        self.runClock = state
            
    def getCurrentBeat(self):
        """
        Get the current beat count.
        
        @param self: The object pointer.
        @return: beatCount: The current beat count.
        """
        return self.beatCounter
        
    def getQueue(self):
        """
        Get the contents of the timed queue.
        
        @param self: The object pointer.
        @return: The list of events in the timed queue.
        """
        return self.queue

    def removeEvent(self, event):
        """
        Remove an event from the timed queue.
        
        @param self: The object pointer.
        @param event: The event to be removed.
        """        
        self.queueMutex.lock(self.removeEvent2, event)

    def removeEvent2(self, event):
        """
        Helper method for removeEvent, thread safe handling of the timed queue list.

        @param self: The object pointer.
        @param event: The event to be removed.
        """
        try:
            self.queue.remove(event)
        except:
            print 'could not remove event not found in queue', event

    def checkQueue(self, beat):
        """
        Check if any events in the queue are due for execution.
        
        Execute any events with timestamp <= timeNow. 
        Times are in beats and so will be relative to the current tempo in bpm, timeNow is a beat counter, and the beat counter may be fractional.
        
        @param self: The object pointer.
        @param beat: The beat count (including any fractional part) used as "now" for dispersing timed events in the queue.
        """
        if self.queue == []:
            return
        if self.queue[0][0] <= beat:
            self.eventCaller.parseEvent(self.queue.pop(0))
            self.checkQueue(beat)

    def insertQueue(self, timeStamp, event):
        """
        Insert an event into the queue, keeping the timeStamps in sorted order.
        
        @param self: The object pointer.
        @param timeStamp: The time to insert the event at.
        @param event: The event to insert.
        """
        self.queueMutex.lock(self.insertQueue2, [timeStamp, event])

    def insertQueue2(self, timeAndEvent):
        """
        Helper method for insertQueue, threadsafe queue access.

        @param self: The object pointer.
        @param timeAndEvent: A list of [timeStamp, event] for insertion into the queue.
        """
        bisect.insort(self.queue, timeAndEvent)

    def insertQueueWithOffset(self, timeStamp, event):
        """
        Insert an event into the queue, keeping the timeStamps in sorted order. The time for the event is offset with the current beat time, so e.g. a time of 1 will be executed one beat into the future.
        
        @param self: The object pointer.
        @param timeStamp: The time to insert the event at.
        @param event: The event to insert.
        """
        self.queueMutex.lock(self.insertQueueWithOffset2, [timeStamp, event])

    def insertQueueWithOffset2(self, timeAndEvent):
        """
        Helper method for insertQueueWithOffset, threadsafe queue access.

        @param self: The object pointer.
        @param timeAndEvent: A list of [timeStamp, event] for insertion into the queue.
        """
        timeStamp, event = timeAndEvent
        timeStamp += (self.beatCounter + self.fractionalBeat)   
        bisect.insort(self.queue, [timeStamp, event])

    def insertListFromNow(self, list):
        """
        Insert a list of timed events into the queue, transposing each event's timestamp relative to the "now" time.
        
        @param self: The object pointer.
        @param list: The list of events to be inserted.
        """
        for event in list:
            event[0] += (self.beatCounter + self.fractionalBeat)
            self.insertQueue(event[0], event[1:])

    def setBpm(self, bpm):
        """
        Set the clock tempo in beats per minute.
        
        @param self: The object pointer.
        """
        self.bpm = bpm
                        
    def stop(self):
        """
        Stops the thread from running, by setting isRunning = False.
        
        @param self: The object pointer.
        """
        self.isRunning = False
        print 'stopping time functions'

