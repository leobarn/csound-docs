#!/usr/bin/python
# -*- coding: latin-1 -*-

""" 
A barebones Python host for Csound

@author: �yvind Brandtsegg
@contact: obrandts@gmail.com
@license: GPL
@requires: csnd
"""

import csnd 
import cs.csMessages
import cs.csModule
import time
import control.eventCaller
import control.theTime2
from constants import *


#--------------------------------------------------------------------------------


#### instantiate eventCaller
eventCaller = control.eventCaller.EventCaller()
"""The event caller is the central module, communication with all other parts of the application."""

theTime = control.theTime2.TheTime2(eventCaller)
"""theTime is the timed queue used for timed automation of method calls."""

#### running csound
csThread = cs.csModule.CsoundThreadRoutine(theTime)
"""Instance of the Csound module, setting up and running Csound."""
csound = csThread.csound
"""Pointer to the actual Csound instance."""
performanceThread = csound#csThread.performanceThread
"""
(Would be) Pointer to the C++ thread running Csound. 
The current implementation does not use the performancethread, but the ksmps loop based method of running Csound. 
The pointer to the performance thread has been implemented to make it feasible to change between ksmps-loop and performancethread driven Csound.
"""
csMessages = cs.csMessages.CsoundMessages(csound, performanceThread) 
"""Instance of csMessages, used for all message passing from python to csound."""

# put pointers to objects into eventCaller
eventCaller.setPointers(csMessages, theTime)

# start csound thread
csThread.csoundThread.start()
# start eventCaller and theTime
eventCaller.initValues()
print 'eventCaller starting threads'
eventCaller.startThreads() 
theTime.runClock = True
"""Set theTime clock to run mode."""

print '**************************************************************************'
print 'available commands:'
print '     perform(module)'
print '     setParameter(module, parameter, value)'
print '     i ... sends a score event to Csound (e.g. "i 1 0 1 -5 60 0.5 0.5")'
print '     other commands:'
print '     eventCaller.setTimeBpm(value)'
print '     eventCaller.recordAudio(START/STOP)'
print 'stop: stop the barebones system and exit the application'
print '**************************************************************************'


# main loop
command = ''
while command != 'stop':
    command = raw_input()
    if command[:8] == 'perform(':
        args = command[8:]
        if 'START' in args:
            module = args.split('START')[0][:-2]
            eventCaller.perform(module, START)
        elif 'STOP' in args:
            module = args.split('STOP')[0][:-2]
            eventCaller.perform(module, STOP)
        else:
            print 'perform must be called with START or STOP argument'
    elif command[:13] == 'setParameter(':
        args = command[13:]
        module, parameter = args.split(',')[:2]
        value = args.partition(parameter)[2]
        while parameter[0] == ' ': parameter = parameter[1:]# remove any leading whitespace from the parameter argument
        while value[0] == ',' or value[0] == ' ': value = value[1:]# remove any leading comma or whitespace from the value argument        
        value = value[:-1] # get rid of trailing parens
        eventCaller.setParameter(module, parameter, value)
    elif command[0] == 'i':
        csMessages.csoundInputMessage(command)
    elif command != 'stop':
        # this might facilitate some variant of live coding with barebones
        c = compile('r='+command, 'string', 'exec')
        try:
            exec(c)
        except:
            print command, 'is not a valid code object, skipping execution of', command
    time.sleep(0)
    
# stop threads
eventCaller.stopThreads() 
csThread.stop()

    