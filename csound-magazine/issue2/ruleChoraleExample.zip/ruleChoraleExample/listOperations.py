# operations to make permutations of lists
# Oeyvind Brandtsegg 2005 - obrandts@online.no

'''
Returns alist of alists with all permutations possible by
first using the first member as 1st, and using all remaining members as 2nd,
then using the second member as 1st, using all remaining members (including old 1st) as 2nd
[1,2,3,4] ->
[1,2], [1,3], [1,4]
[2,1], [2,3], [2,4] ... etc

'''

import copy

def allPermutations(alist, out=[]):
    '''
    Return a list of lists, containing all possible reorderings of alist.
    Works well for list size up to 3 members,
    probably just some small trick to make it recursive and work for larger lists.
    '''
    buildlist = eachToAllSecond(alist)
    for member in buildlist:
        alistCopy = copy.copy(alist)
        for submember in member:
            alistCopy.remove(submember)
        member.extend(alistCopy)
    return buildlist

def eachToAllSecond(alist):
    '''
    Combine the each element in a list with each of the other elements,
    returning a list of lists.
    Example:
    >>> eachToAllSecond([1,2,3,4])
    [[1, 2], [1, 3], [1, 4], [2, 3], [2, 4], [2, 1],
    [3, 4], [3, 1], [3, 2], [4, 1], [4, 2], [4, 3]]
    '''
    out = []
    for i in range(0, len(alist)):
        alistCopy = copy.copy(alist)
        new = firstToAllSecond(alistCopy)
        for member in new:
            out.append(member)
        #rotate
        first = alist.pop(0)
        alist.append(first)
    return out

def firstToAllSecond(alist):
    '''
    Combine the first element in a list with each of the other elements,
    returning a list of lists.
    Example:
    >>> firstToAllSecond([1,2,3,4])
    [[1, 2], [1, 3], [1, 4]]
    '''
    out = []
    orig = copy.copy(alist)
    first = alist.pop(0)
    while alist:
        second = alist.pop(0)
        out.append([first,second])
    return out

def appendToEach(item, alist):
    '''
    Append item to each member of alist.
    Item may be a list and alist may be a list of lists
    Return alist
    Examples:
    >>> appendToEach(5, [1,2])
    [[1, 5], [2, 5]]
    >>> appendToEach([5,6], [[1,2],[3,4]])
    [[1, 2, 5, 6], [3, 4, 5, 6]]
    '''
    if type(item) is not list:
        item = [item]
    for member in alist:
        index = alist.index(member)
        if type(member) is not list:
            member = [member]
        member.extend(item)
        alist[index] = member
    return alist

def findAllCombinationsListOfLists(alist):
    '''
    Returns a list of lists with all combinations possible
    by combining one member from each of two list.
    Lists may have different lengths.
    If there are more than two lists in alist, they are combined pairwise,
    then there must be an even number of sublists (e.g. 4 or 6 sublists.
    Example:
    [[1,2], [3,4]] -> [[1,3], [1,4], [2,3], [2,4]]
    [[1,2], [3,4,5] -> [[1,3], [1,4], [1,5], [2,3], [2,4], [2,5]]
    >>>alist = [[1,2],[3,4],[5,6],[7,8]]
    >>> findAllCombinationsListOfLists(alist)
    [[1, 3], [1, 4], [2, 3], [2, 4], [5, 7], [5, 8], [6, 7], [6, 8]]
    '''
    combo = []
    while len(alist) >= 2:
        sub1 = alist.pop(0)
        sub2 = alist.pop(0)
        for item in sub1:
            for item2 in sub2:
                combo.append([item, item2])
    return combo

def factorial(n, result=1):
    '''
    Returns the factorial of n
    '''
    while n > 1:
        result=n*result
        n = n - 1
    return result

def listRotate(alist, amount):
    '''
    Rotates the members of a list
    '''
    if amount > 0:
        for i in range(0,amount):
            temp = alist.pop(0)
            alist.append(temp)
    if amount < 0:
        for i in range(0,abs(amount)):
            temp = alist.pop(-1)
            alist.insert(0, temp)

def findAllMinimum(alist):
    '''
    Return a list of indices to all values equal to the minimum value in a list.
    If only one value is the minimum of alist, this function would equal alist.index(min(alist))
    '''
    minimum = min(alist)
    minList = []
    index = 0
    for item in alist:
        if item == minimum:
            minList.append(index)
        index += 1
    return minList

def findAllMaximum(alist):
    '''
    Return a list of indices to all values equal to the minimum value in a list.
    If only one value is the minimum of alist, this function would equal alist.index(min(alist))
    '''
    maximum = max(alist)
    maxList = []
    index = 0
    for item in alist:
        if item == maximum:
            maxList.append(index)
        index += 1
    return maxList
