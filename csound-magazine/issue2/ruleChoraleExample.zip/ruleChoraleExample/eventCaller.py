# This is a "glue" module, collecting inputs from both GUI and the timed queue,
# throughputting function calls to the various modules.
# It seemed tidier to keep all the imports and references to various modules in one place,
# instead of cluttering up all other modules
# Oeyvind Brandtsegg 2006 - obrandts@online.no

import time
import csMessages
import ruleChorale
chorale1 = ruleChorale.IntervalMelody()


theTime = 'instance pointer for timed Events class'
theTimeSeconds = 'instance pointer for timed Events class'
theGUI = 'instance pointer for the GUI class'


class EventCaller:
    '''
    Functions for calling other functions.
    This is a very central "glue" module that communicates with GUI/Time/Queue/other inputes,
    and forwards properly formatted function calls to the underlying "worker" modules.
    '''

    def __init__(self):
        self.autoChorale = [0,0,0,0,0]
            
    def makeVoiceGroup(self, startstop, voiceGroup):
        '''
        Start or stop a voice group
        '''
        if startstop == 1:
            pfields = (501, 0, 2, voiceGroup) # start the voice group instrument
        if startstop == 0:
            pfields = (501, 0, 2, -voiceGroup)
        csMessages.csoundEventGeneric(pfields)

    def startChorale(self, voice, basePitch, mutationType='normalMutation', seriesIndex=-1):
        '''
        Starts a timed process generating one melody note at a time.
        The rhythm and melody is based on a simple interval series melody generator.
        '''
        pitch, mutationType, seriesIndex, delta = chorale1.nextNote(voice, basePitch, mutationType, seriesIndex)
        instr = 1004
        duration = delta * (60.0/theTime.bpm)
        velocity = 70
        voiceGroup = voice
        csMessages.csoundEvent(instr, duration, voiceGroup, pitch, velocity)
        if delta == 4:
            delta += 2 # make a rest after long notes

        # schedule the updating of chorale1.pitchClassesInUse when the note is turned off
        theTime.insertQueueWithOffset(delta-0.01, ['simpleChoralePitchNotInUse', voice])

        if self.autoChorale[voice-1] == 1:
            theTime.insertQueueWithOffset(delta, ['simpleChorale', voice, pitch, mutationType, seriesIndex])

    def startChorale2(self, voice, basePitch, mutationType='normalMutation', seriesIndex=-1):
        '''
        Starts a timed process generating a harmony melody to chorale voice 1
        '''
        # find voice 1 event in theTime.queue,
        # insert a secondary voice event at the same time stamp as the next voice 1 event
        for event in theTime.queue:
            if event[1][:2] == ['simpleChorale', 1]:
                timeStamp = event[0]
                theTime.insertQueue(timeStamp, ['simpleChorale', voice, basePitch, mutationType, seriesIndex])
                return
        print "no events for voice 1, secondary voice event not inserted in queue"
        if len(theTime.queue) == 0:
            print 'time queue has no events'
            

# instantiate the class
eventCaller1 = EventCaller()
