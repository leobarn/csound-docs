# This is an interface module for communication from Python to Csound.
# All note events messages sent to csound is collected here
# Oeyvind Brandtsegg 2005 - obrandts@online.no

import csnd

# initialize the string
# it will be overwritten by a pointer to the global csoundVST instance
csound = "global csound instance"


def csoundEvent(instr, duration, voiceGroup, note, velocity):
    ''' sends a note event to csound'''

    csParameters = (instr, 0, duration, voiceGroup, note, velocity)
    csound.InputMessage("i %f %f %f %f %f %f" %csParameters)

def csoundEventGeneric(pfields):
    '''
    Generic access to sending events to csound,
    all p-fields must be valid and in correct order,
    no checking or processing done here
    '''
    strPfields = 'i'
    for item in pfields:
        strPfields = '%s %f' %(strPfields, item)
    csound.InputMessage(strPfields)

def getCsoundBusChannels():
    '''
    Return a list of all allocated bus channels between python and csound
    '''
    chnlst = csnd.CsoundChannelList(csound)
    channelList = []
    n = chnlst.Count()
    for i in range(n):
        item = []
        item.append(chnlst.Name(i))
        if chnlst.IsControlChannel(i):
            item.append('control')
        elif chnlst.IsAudioChannel(i):
            item.append('audio')
        elif chnlst.IsStringChannel(i):
            item.append('string')
        channelList.append(item)
    return channelList
    
def listCsoundBusChannels():
    '''
    Print a list of all allocated bus channels between python and csound
    '''
    chnlst = csnd.CsoundChannelList(csound)

    n = chnlst.Count()
    if n > 0:
        print '============================================================'
        print 'Csound chn channels listing'
        print 'Currently using', n, 'channels'
        print '------------------------------------------------------------'
    for i in range(n):
        print 'Name:', chnlst.Name(i)
        if chnlst.IsControlChannel(i):
            print '       | Type: control', '| Input:', ['no', 'yes'][chnlst.IsInputChannel(i)], '| Output:', ['no', 'yes'][chnlst.IsOutputChannel(i)]
        elif chnlst.IsAudioChannel(i):
            print '       | Type: audio', '| Input:', ['no', 'yes'][chnlst.IsInputChannel(i)], '| Output:', ['no', 'yes'][chnlst.IsOutputChannel(i)]
        elif chnlst.IsStringChannel(i):
            print '       | Type: string', '| Input:', ['no', 'yes'][chnlst.IsInputChannel(i)], '| Output:', ['no', 'yes'][chnlst.IsOutputChannel(i)]

def sendVoiceGroupControlToCsound(parameter, voiceGroupNum, value):
    '''
    send a control value to csound, using the software bus and chn opcode in csound
    '''
    channelName = "VoiceGroup%d_%s" %(voiceGroupNum, parameter)
    channel = " "   # empty, for testing if channel excists

    # read channel list, find channel name and voice group
    for item in getCsoundBusChannels():
        if item[0] == channelName:
            channel = channelName
    if channel == " ":
        print 'csound bus channel name not found'
    else:
        # send value to channel
        csound.SetChannel(channel, value)
        print 'sent control', channel, value

def sendMasterControlToCsound(parameter, value):
    '''
    send a control value to csound, using the software bus and chn opcode in csound
    '''
    channelName = parameter
    channel = " "   # empty, for testing if channel excists

    # read channel list, find channel name and voice group
    for item in getCsoundBusChannels():
        if item[0] == channelName:
            channel = channelName
    if channel == " ":
        print 'csound bus channel name not found'
    else:
        # send value to channel
        csound.SetChannel(channel, value)
        print 'sent control', channel, value

