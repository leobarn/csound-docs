# Functions to be called from the Gui
# these would be functions to interface the Gui to the rest of the application
# Oeyvind Brandtsegg 2006 - obrandts@online.no


import eventCaller
eventCaller1 = eventCaller.eventCaller1
ruleChorale = eventCaller.chorale1

import csMessages
import time

# initialize the pointer
# it will be overwritten by a pointer to the global instance
csound = "instance pointer"
theGUI = "instance pointer"
 
class GuiTriggeredEvents:
    '''
    The class holding functions for GUI triggered events
    '''
    def __init__(self):
        self.voiceGroupControlNum = 1

    def onVoiceGroupStart(self, event):
        # start voice group
        eventCaller1.makeVoiceGroup(1, self.voiceGroupControlNum)
        # get values for voice group and initialize
        print 'voice group level set to ', theGUI.voiceGroupLevelCtrl.GetValue()
        time.sleep(0)
        csMessages.sendVoiceGroupControlToCsound("Level", self.voiceGroupControlNum, theGUI.voiceGroupLevelCtrl.GetValue()*0.01)

    def onVoiceGroupStop(self, event):
        # stop voice group
        eventCaller1.makeVoiceGroup(0, self.voiceGroupControlNum)

    def onListBusChannels(self, event):
        # list the bus channels between python and csound
        csMessages.listCsoundBusChannels()
         
    def onVoiceGroupControlNum(self, event):
        # store current voice group num to send control signals to from GUI
        self.voiceGroupControlNum = event.GetInt()

    def onVoiceGroupReverbSend(self, event):
        # send control signal to selected voice group
        csMessages.sendVoiceGroupControlToCsound("ReverbSend", self.voiceGroupControlNum, event.GetInt()*0.01)

    def onVoiceGroupLevel(self, event):
        # send control signal to selected voice group
        csMessages.sendVoiceGroupControlToCsound("Level", self.voiceGroupControlNum, event.GetInt()*0.01)

    def onVoiceGroupPitch(self, event):
        # send control signal to selected voice group
        csMessages.sendVoiceGroupControlToCsound("pitchBend", self.voiceGroupControlNum, event.GetInt()*0.01)

    def onMasterLevel(self, event):
        # send master level changes
        csMessages.sendMasterControlToCsound("MasterLevel", event.GetInt()*0.01)

    def onChorale1Start(self, event):
        # start rule choral melody process
        voice = 1
        eventCaller1.autoChorale[voice-1] = 1
        basePitch = 60
        eventCaller1.startChorale(voice, basePitch)

    def choraleVoiceStart(self, voice, basePitch):
        # start additional voice in rule choral melody process
        eventCaller1.autoChorale[voice-1] = 1
        eventCaller1.startChorale2(voice, basePitch)

    def onChorale2Start(self, event):
        # helper function, because could not figure out how to send arguments to function from GUI
        self.choraleVoiceStart(2, 60)
    def onChorale3Start(self, event):
        # helper function, because could not figure out how to send arguments to function from GUI
        self.choraleVoiceStart(3, 48)
    def onChorale4Start(self, event):
        # helper function, because could not figure out how to send arguments to function from GUI
        self.choraleVoiceStart(4, 48)
    def onChorale5Start(self, event):
        # helper function, because could not figure out how to send arguments to function from GUI
        self.choraleVoiceStart(5, 84)

    def onChoraleStop(self, event):
        # stop rule chorale all voices
        for i in range(0,5):
            eventCaller1.autoChorale[i] = 0
    def onChorale2Stop(self, event):
        # stop rule chorale melody voice
        eventCaller1.autoChorale[1] = 0
    def onChorale3Stop(self, event):
        # stop rule chorale melody voice
        eventCaller1.autoChorale[2] = 0
    def onChorale4Stop(self, event):
        # stop rule chorale melody voice
        eventCaller1.autoChorale[3] = 0
    def onChorale5Stop(self, event):
        # stop rule chorale melody voice
        eventCaller1.autoChorale[4] = 0

    def onRuleChoraleIntervalSeries(self, event):
        '''
        Update the melodic interval series for the ruleChorale melody generator
        '''
        intervallist = self.getFloatlistFromEvent(event)
        ruleChorale.intervalSeries = [] # clear list, as new list might have different length
        for item in intervallist:
            ruleChorale.intervalSeries.append(item)
        print 'current interval series : ', ruleChorale.intervalSeries

    def onRuleChoraleVoiceRange(self, event):
        '''
        Set the voice range for the rule chorale melody generator
        '''
        voicerangelist = self.getFloatlistFromEvent(event)
        ruleChorale.loLimit = voicerangelist[0]
        ruleChorale.hiLimit = voicerangelist[1]

    def onRuleChoraleHarmonicIntervalSet(self, event):
        '''
        Set the scores for each (of the 11) harmonic intervals.
        Input is a list of scores, outputs a list of lists [[interval, score], [i,s]...]
        '''
        scorelist = self.getFloatlistFromEvent(event)
        if len(scorelist) < 11:
            print 'warning: you did specify score for only %i out of 11 intervals' %len(scorelist)
        index = 0
        for item in scorelist:
            ruleChorale.harmonicIntervalScore[index] = [index,item]
            index += 1
        print 'current harmonicIntervalScore : ', ruleChorale.harmonicIntervalScore

    def onRuleChoraleHarmonicScoreWeight(self, event):
        '''
        Set the harmonic score for the rule chorale melody generator,
        tilting the bias towards regarding harmony more importent than melody (intervals)
        '''
        ruleChorale.harmonicScoreWeight = float(event.GetString())
        
    def onRuleChoraleMutationTypeScores(self, event):
        '''
        Set the scores for the normal, reversed, inverted and reverseinverted series mutations.
        The input is a list, outputs to 4 separate variables in ruleChorale
        '''
        mutationScorelist = self.getFloatlistFromEvent(event)
        ruleChorale.seriesNormalScore = mutationScorelist[0]
        ruleChorale.seriesReverseScore = mutationScorelist[1]
        ruleChorale.seriesInverseScore = mutationScorelist[2]
        ruleChorale.seriesRevInvScore = mutationScorelist[3]
        
    def onRuleChoraleChangeMutationTypeScore(self, event):
        '''
        Sets the score (normally negative) for changing mutation type in ruleChorale
        '''
        ruleChorale.changeMutationScore = float(event.GetString())

    def onRecordEnableRuleChoraleIntervalSeries(self, event):
        '''
        Enable midi recording of interval series, clearing any previous interval series when recording new intervals
        '''
        csMessages.recordEnableRuleChoraleIntervalSeries = event.IsChecked()
        csMessages.previousNoteNum = 0
        
    def onTempoBpmEnter(self, event):
        # tempo in bpm
        # use numbers only, convert to float
        eventCaller.theTime.bpm = float(event.GetString())


######## utility
        
    def getFloatlistFromEvent(self, event):
        '''
        Get a list of floats from a GUI event
        '''
        floatlist = []
        eventstring = event.GetString()
        for item in eventstring.split(','):
            try:
                value = float(item)
                floatlist.append(value)
            except:
                print 'illegal entry for list from GUI, use comma separated ints or floats (no parens or brackets)'
        return floatlist
