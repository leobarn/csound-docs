Run ruleMain.py to start.  Need Python2.4 and probably Csound 5.02.

SEE THE ARTICLE FOR INSTRUCTIONS ON HOW TO RUN THE MODULES.

--JH