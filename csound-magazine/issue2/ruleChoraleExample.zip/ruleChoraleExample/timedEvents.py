# The timed queue and the master clock 
# Oeyvind Brandtsegg 2005 - obrandts@online.no

import threading
from wxPython.wx import *
import time
import bisect
import eventCaller
eventCaller1 = eventCaller.eventCaller1

class TheTime(threading.Thread):
    '''
    The class holding timer and rhythm trigger functions.
    This also holds a queue of events to be executed in time,
    format for the queue is a list of events,
    with each event represented as a list with the following format:
    [type, time, data]
    The type field is a string, to be parsed in self.parseEvents().
    Time is in beats and may be fractional.
    The data field may contain several parameters (extending the list).
    '''
    def __init__(self):
        threading.Thread.__init__(self)
        self.isRunning = True
        self.timeResolution = 0.001 # millisecond resolution
#        self.timeResolution = 1.0 # one second resolution
        self.queue = []
        self.beatCounter = 0.0 # counter for quarter notes at a given bpm
        self.fractionalBeat = 0 # counter for fractions of a beat
        self.bpm = 60 # the beats per minute for the beat counter
        self.timeNow = 0 #
        self.timeAtStart = time.clock()
        
    def run(self): 
        '''
        The main clock function, also polling the event queue
        '''
        prevTime = 0
        nextBeatTime = 0
        while (self.isRunning):
            timePerBeat = 60.0 / self.bpm
            self.timeNow = time.clock()
            # update beat counter
            if self.timeNow >= nextBeatTime:
                self.beatCounter += 1
                self.fractionalBeat = 0
                nextBeatTime = self.timeNow + timePerBeat                
            # update the fractional beat counter
            if self.timeNow >= prevTime + self.timeResolution:
                # check queue here, execute pending events in queue,
                if self.queue != []:
                    self.checkQueue(self.beatCounter+self.fractionalBeat)
                self.fractionalBeat += ((self.timeNow-prevTime)/timePerBeat)
                prevTime = self.timeNow
            time.sleep(0)

    def checkQueue(self, beat):
        '''
        Check if any events in the queue are due for execution.
        Execute any events with timestamp <= timeNow. 
        Times are in beats and so will be relative to the current tempo in bpm,
        timeNow is a beat counter,
        and the beat counter may be fractional
        '''
        if self.queue == []:
            print 'queue empty', self.queue
            return
        if self.queue[0][0] <= beat:
            self.parseEvent(self.queue[0][1])
            self.queue.pop(0)
            self.checkQueue(beat)

    def insertQueue(self, timeStamp, event):
        '''
        Insert an event into the queue, keeping the timeStamps in sorted order
        '''
        bisect.insort(self.queue, [timeStamp, event])
        print 'inserted event at %f' %timeStamp

    def insertQueueWithOffset(self, timeStamp, event):
        '''
        Insert an event into the queue, keeping the timeStamps in sorted order.
        The time for the event is offset with the current beat time,
        so e.g. a time of 1 will be executed one beat into the future.
        '''
        timeStamp += (self.beatCounter + self.fractionalBeat)   
        bisect.insort(self.queue, [timeStamp, event])
#        print 'inserted event at %f' %timeStamp

    def insertListFromNow(self, list):
        '''
        Insert a list of timed events into the queue, transposing each event's timestamp
        relative to the "now" time
        '''
        for event in list:
            event[0] += (self.beatCounter + self.fractionalBeat)
            self.insertQueue(event[0], event[1:])
            
    def parseEvent(self, event):
        '''
        Parsing of events output from queue.
        '''
        eventType = event[0]
        data = event[1:]
        if eventType == 'csoundEvent':
            print 'not implemented ? '
            #eventCaller1.csoundEventGeneric(data)
        elif eventType == 'simpleChorale':
            voice,basePitch, mutationType, seriesIndex = data    
            eventCaller1.startChorale(voice, basePitch, mutationType, seriesIndex)
        elif eventType == 'simpleChoralePitchNotInUse':
            voice = data[0]
            eventCaller.chorale1.pitchClassesInUse[voice] = -1
            #print 'updated choralpitches in use', eventCaller.chorale1.pitchClassesInUse
        else:
            print 'event in timed queue of unknown type', event

    def stop(self):
        '''
        stop the thread
        '''
        self.isRunning = False
        print 'stopping time functions'

#########################
def test(type):
    '''
    a simple test
    '''
    # instantiate the class
    theTime = TheTime()

    if type == 1:
        theTime.bpm = 30
        # an example queue list, testing fractional beat time
        theTime.queue = [[2,'ding'],[3,'ding'],[4,'dong'],
                         [5,'bang'],[5.5, 'bang and a half'], [6, 'sizz']]
        theTime.start()
        time.sleep(13)
        theTime.stop()
        return
    else:
        # an example queue list
        theTime.queue = [[1,'ding'],[2,'dong'],[5,'bang'],[5.5, 'bang and a half'], [6, 'sizz'],
                          [8,'bonk'],[8,'bonk'],[8,'bonk'],[8,'bonk'],[9,'last one']]
        # take a copy of the queue, to test insertion of a copy later
        import copy
        queueCopy = copy.copy(theTime.queue)

        # start the time and queue function
        theTime.start()
        time.sleep(12)
        # insert event in realtime
        theTime.insertQueue(14, 'new event at 14')
        theTime.insertQueue(17, 'new event at 17')
        time.sleep(1)
        theTime.insertQueue(15, 'new event at 15')
        time.sleep(10)
        # insert list of events in realtime
        theTime.insertListFromNow(queueCopy)
        theTime.bpm = 160
        print 'tempo changed to 160'
        time.sleep(12)
        theTime.stop()

if __name__ == '__main__':
    print 'testing, using various unknown event types'
    test(0)
