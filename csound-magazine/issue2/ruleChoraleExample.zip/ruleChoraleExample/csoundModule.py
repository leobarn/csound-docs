# The csound module, setting up csound orc/sco and calling csound.PerformKsmps every k-rate period
# Oeyvind Brandtsegg 2005 - obrandts@online.no

import threading
from wxPython.wx import *
import csnd

class CsoundThread(threading.Thread):
        def __init__(self, csound, commandline):
	    threading.Thread.__init__(self)
            self.isRunning = True
	    self.csound = csound
	    self.commandline = commandline
            print "csound loaded"
#            self.locked = 0
	def run(self):
            # Embed an orchestra in this script.
            self.csound.setOrchestra('''#include 'ruleChorale.orc'
            ''')
            # And a score.
            self.csound.setScore('''#include 'ruleChorale.sco'
            ''')
            # Command line
            self.csound.setCommand('''%s''' %self.commandline)
            # Export the orc and sco.
            self.csound.exportForPerformance()
            # Start the performance.
            self.csound.compile()
            while(self.isRunning):
                self.csound.PerformKsmps()
                # Absolutely MUST yield to wxWindows or the app will freeze!
                #wxYield()
#                print 'running'
            self.csound.Reset()
            self.csound.Cleanup()

        def stop(self):
            '''
            stop the csound thread loop
            '''
            print 'stopping csound'
            self.isRunning = False
    

