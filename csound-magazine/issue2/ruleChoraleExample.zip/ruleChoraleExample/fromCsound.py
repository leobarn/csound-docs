# This module handles all messages coming from Csound,
# to be forwarded to various python modules
# Oeyvind Brandtsegg 2006 - obrandts@online.no

import eventCaller

def audioMasterLevelRms(rms1, rms2):
    '''
    Receive rms level as measured at the global output in Csound.
    Update the GUI signal display
    '''
    eventCaller.theGUI.updateVuMeters(rms1, rms2)


# some globals related to routing of midi when recording
# put these as class variables when this module is reimplemented as class
recordEnableRuleChoraleIntervalSeries = 0
previousNoteNum = 0
intervalSeriesClearFlag = 0
import copy

def midiNoteInput(noteNum, velocity):
    '''
    receives realtime midi note on data from csound
    '''
    print 'csound midi note input:', noteNum, velocity
    if recordEnableRuleChoraleIntervalSeries == 1:
        updateRuleChoraleIntervalSeries(noteNum)

def midiNoteInputOff(noteNum):
    '''
    receives realtime midi note off data from csound
    '''
    print 'csound midi note off:', noteNum
    pass

def updateRuleChoraleIntervalSeries(noteNum):
    '''
    update the interval series with intervals derived from realtime midi input
    '''
    # get the current interval series
    intervalSeries = copy.copy(eventCaller.chorale1.intervalSeries)
    # convert noteNum to int for better display
    noteNum = int(noteNum)
    global previousNoteNum
    global intervalSeriesClearFlag
    if previousNoteNum == 0: # the first note input only sets previousNoteNum and returns, setting up to measure first interval
        previousNoteNum = noteNum
        intervalSeriesClearFlag = 1
        return
    if intervalSeriesClearFlag == 1:
        intervalSeries = []
        intervalSeriesClearFlag = 0
    interval = noteNum - previousNoteNum
    previousNoteNum = noteNum
    intervalSeries.append(interval)
    intervalSeriesString = ""
    for item in intervalSeries:
        if type(item) == int:
            item = str(item)
            intervalSeriesString += item
            intervalSeriesString += ", " #comma and whitespace
    # slice off last comma and whitespace
    intervalSeriesString = intervalSeriesString[:-2]
    print 'interval series', intervalSeriesString
    eventCaller.theGUI.updateRuleChoraleIntervalSeries(intervalSeriesString)        
    eventCaller.chorale1.intervalSeries = intervalSeries
