# The main module, it's only work is to set up and instantiate all other modules
# Oeyvind Brandtsegg 2006 - obrandts@online.no


# import wx
from wxPython.wx import *
import threading
import time
import csoundModule
import csMessages
import fromCsound
import testGui
import guiTriggeredEvents
import eventCaller
import timedEvents

# test csnd
import csnd
csound = csnd.CppSound()
csound.setPythonMessageCallback()


#--------------------------------------------------------------------------------
# Create a csoundVST instance in it's own thread,
# all Csound related stuff is located in csoundFuzzy.py

# set the parameters for the csound command line 
csoundCommandline = "csound -m0 temp.orc temp.sco"
# Create the Csound thread
csThread = csoundModule.CsoundThread(csound, csoundCommandline)
# pointer to csound thread inside imported modules

csoundModule.csound = csound

testGui.csound = csound
testGui.guiTriggeredEvents.csound = csound
csMessages.csound = csound
#--------------------------------------------------------------------------------

# instantiate the timed events class
theTime = timedEvents.TheTime() # a Beats Per Minute based timed queue
theTimeSeconds = timedEvents.TheTime() # a separate timer with tempo = 60 bpm always
theTimeSeconds.bpm = 60

# put a pointer to the timed events instance in the eventCaller module
eventCaller.theTime = theTime
eventCaller.theTimeSeconds = theTimeSeconds


#--------------------------------------------------------------------------------


#--------------------------------------------------------------------------------

# Main body of app

ctrl_app = wxPySimpleApp()
frame = wxFrame( None, -1, "Csound Controller" )
ctrl_panel = testGui.ControlPanel( frame )
# pointer to the GUI instance inside the eventCaller module
eventCaller.theGUI = ctrl_panel
guiTriggeredEvents.theGUI = ctrl_panel

frame.Show(True)

# start the various threads
csThread.start()
theTime.start()
theTimeSeconds.start()


ctrl_app.MainLoop()
# stop threads
theTime.stop()
theTimeSeconds.stop()
csThread.stop()

# End of main body

