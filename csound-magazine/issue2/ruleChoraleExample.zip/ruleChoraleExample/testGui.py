# The Gui window and controls
# Oeyvind Brandtsegg 2006 - obrandts@online.no


from wxPython.wx import *
import guiTriggeredEvents

gte = guiTriggeredEvents.GuiTriggeredEvents()

# initialize the string
# it will be overwritten by a pointer to the global csoundVST instance
csound = "global csound instance"

# hack pointer to the main instance of the ControlPanel class
mainpanel = "pointer to main panel"

# GUI element IDs
ID_TXT_BPM = 1
ID_MasterLevel = 2
ID_VuMeterL = 3
ID_VuMeterR = 4

ID_VoiceGroupStart = 11
ID_VoiceGroupStop = 12
ID_VoiceGroupStartNum = 13
ID_ListBusChan = 14
ID_VoiceGroupControlNum = 15
ID_VoiceGroupReverbSend = 16
ID_VoiceGroupLevel = 17

ID_Chorale1Start = 31
ID_Chorale2Start = 32
ID_Chorale3Start = 33
ID_Chorale4Start = 34
ID_Chorale5Start = 35

ID_Chorale1Stop = 36
ID_Chorale2Stop = 37
ID_Chorale3Stop = 38
ID_Chorale4Stop = 39
ID_Chorale5Stop = 40

ID_RuleChoraleIntervalSeries = 41
ID_RuleChoraleVoiceRange = 42
ID_RuleChoraleHarmonicIntervalSet = 43
ID_RuleChoraleHarmonicScoreWeight = 44
ID_RuleChoraleMutationTypeScores = 45
ID_RuleChoraleChangeMutationTypeScore = 46

ID_RecordEnableRuleChoraleIntervalSeries = 47


# declare my ControlPanel class, inherit from standard wx.Panel
class ControlPanel( wxPanel ):

	# overide the standard wx.Panel constructor	
	def __init__(self, parent):

		# call the parent classes constructor to begin with	
		wxPanel.__init__( self, parent, -1 )	

                # define some GUI widgets, to be added to a Sizer later

                # labels
                self.MasterLabel = wxStaticText(self, -1, "master controls", (0, 0))
                self.VoiceGroupLabel = wxStaticText(self, -1, "voice group controls", (0, 0))

                # text boxes
                self.tempoBpmCtrl = wxTextCtrl(self, ID_TXT_BPM, "60", (0, 0), (30, 20) )
                EVT_TEXT_ENTER(self, ID_TXT_BPM, gte.onTempoBpmEnter)
                self.tempoBpmLabel = wxStaticText(self, -1, "tempo bpm", (0, 0))

                self.ruleChoraleIntervalSeriesCtrl = wxTextCtrl(self, ID_RuleChoraleIntervalSeries, "1,4,-1,-2", (0, 0),(135,20))
                EVT_TEXT_ENTER(self, ID_RuleChoraleIntervalSeries, gte.onRuleChoraleIntervalSeries)
                self.ruleChoraleIntervalSeriesLabel = wxStaticText(self, -1, "interval series", (0, 0))

                self.ruleChoraleVoiceRangeCtrl = wxTextCtrl(self, ID_RuleChoraleVoiceRange, "48,84", (0, 0))
                EVT_TEXT_ENTER(self, ID_RuleChoraleVoiceRange, gte.onRuleChoraleVoiceRange)
                self.ruleChoraleVoiceRangeLabel = wxStaticText(self, -1, "voice range", (0, 0))

                self.ruleChoraleHarmonicIntervalSetCtrl = wxTextCtrl(self, ID_RuleChoraleHarmonicIntervalSet, "0,1,1,4,4,3,0,3,4,4,1,1", (0, 0),(135,20))
                EVT_TEXT_ENTER(self, ID_RuleChoraleHarmonicIntervalSet, gte.onRuleChoraleHarmonicIntervalSet)
                self.ruleChoraleHarmonicIntervalSetLabel = wxStaticText(self, -1, "harmonic interval set", (0, 0))

                self.ruleChoraleHarmonicScoreWeightCtrl = wxTextCtrl(self, ID_RuleChoraleHarmonicScoreWeight, "1", (0, 0))
                EVT_TEXT_ENTER(self, ID_RuleChoraleHarmonicScoreWeight, gte.onRuleChoraleHarmonicScoreWeight)
                self.ruleChoraleHarmonicScoreWeightLabel = wxStaticText(self, -1, "harmonic score", (0, 0))

                self.ruleChoraleMutationTypeScoresCtrl = wxTextCtrl(self, ID_RuleChoraleMutationTypeScores, "4,3,2,1", (0, 0))
                EVT_TEXT_ENTER(self, ID_RuleChoraleMutationTypeScores, gte.onRuleChoraleMutationTypeScores)
                self.ruleChoraleMutationTypeScoresLabel = wxStaticText(self, -1, "mutation type scorelist", (0, 0))

                self.ruleChoraleChangeMutationTypeScoreCtrl = wxTextCtrl(self, ID_RuleChoraleChangeMutationTypeScore, "-1", (0, 0))
                EVT_TEXT_ENTER(self, ID_RuleChoraleChangeMutationTypeScore, gte.onRuleChoraleChangeMutationTypeScore)
                self.ruleChoraleChangeMutationTypeScoreLabel = wxStaticText(self, -1, "change mutation score", (0, 0))

		# buttons
		self.voiceGroupStartCtrl = wxButton(self, ID_VoiceGroupStart, "voice group start", (0, 0))
		EVT_BUTTON(self, ID_VoiceGroupStart, gte.onVoiceGroupStart)
		
		self.voiceGroupStopCtrl = wxButton(self, ID_VoiceGroupStop, "voice group stop", (0, 0))
		EVT_BUTTON(self, ID_VoiceGroupStop, gte.onVoiceGroupStop)

		self.listBusChanCtrl = wxButton(self, ID_ListBusChan, "list bus channels", (0, 0))
		EVT_BUTTON(self, ID_ListBusChan, gte.onListBusChannels)

		self.chorale1StartCtrl = wxButton(self, ID_Chorale1Start, "chorale1 start", (0, 0))
		EVT_BUTTON(self, ID_Chorale1Start, gte.onChorale1Start)

		self.chorale2StartCtrl = wxButton(self, ID_Chorale2Start, "chorale2 start", (0, 0))
		EVT_BUTTON(self, ID_Chorale2Start, gte.onChorale2Start)

		self.chorale3StartCtrl = wxButton(self, ID_Chorale3Start, "chorale3 start", (0, 0))
		EVT_BUTTON(self, ID_Chorale3Start, gte.onChorale3Start)

		self.chorale4StartCtrl = wxButton(self, ID_Chorale4Start, "chorale4 start", (0, 0))
		EVT_BUTTON(self, ID_Chorale4Start, gte.onChorale4Start)

		self.chorale5StartCtrl = wxButton(self, ID_Chorale5Start, "chorale5 start", (0, 0))
		EVT_BUTTON(self, ID_Chorale5Start, gte.onChorale5Start)

		self.chorale1StopCtrl = wxButton(self, ID_Chorale1Stop, "chorale stop", (0, 0))
		EVT_BUTTON(self, ID_Chorale1Stop, gte.onChoraleStop)
              
		self.chorale2StopCtrl = wxButton(self, ID_Chorale2Stop, "chorale stop 2", (0, 0))
		EVT_BUTTON(self, ID_Chorale2Stop, gte.onChorale2Stop)

		self.chorale3StopCtrl = wxButton(self, ID_Chorale3Stop, "chorale stop 3", (0, 0))
		EVT_BUTTON(self, ID_Chorale3Stop, gte.onChorale3Stop)

		self.chorale4StopCtrl = wxButton(self, ID_Chorale4Stop, "chorale stop 4", (0, 0))
		EVT_BUTTON(self, ID_Chorale4Stop, gte.onChorale4Stop)

		self.chorale5StopCtrl = wxButton(self, ID_Chorale5Stop, "chorale stop 5", (0, 0))
		EVT_BUTTON(self, ID_Chorale5Stop, gte.onChorale5Stop)

                # spin ctrl
		self.voiceGroupControlNumCtrl = wxSpinCtrl(self, ID_VoiceGroupControlNum, "1", (0, 0), (-1, -1),
				   wxSP_ARROW_KEYS, 0, 5, 1, ""  )
		EVT_SPINCTRL(self, ID_VoiceGroupControlNum, gte.onVoiceGroupControlNum)
                self.voiceGroupControlNumLabel = wxStaticText(self, -1, "VoiceGroup select", (0, 0))

                # slider
		self.masterLevelCtrl = wxSlider(self, ID_MasterLevel, 50, 0, 100, (0, 0), (100,40),
				   wxSL_HORIZONTAL | wxSL_LABELS )
		EVT_SLIDER(self, ID_MasterLevel, gte.onMasterLevel )
                self.masterLevelLabel = wxStaticText(self, -1, "Master Level", (0, 0))
                
		self.voiceGroupReverbSendCtrl = wxSlider(self, ID_VoiceGroupReverbSend, 20, 0, 100, (0, 0), (100,40),
				   wxSL_HORIZONTAL | wxSL_LABELS )
		EVT_SLIDER(self, ID_VoiceGroupReverbSend, gte.onVoiceGroupReverbSend )
                self.voiceGroupReverbSendLabel = wxStaticText(self, -1, "VoiceGroup reverb send", (0, 0))

		self.voiceGroupLevelCtrl = wxSlider(self, ID_VoiceGroupLevel, 100, 0, 100, (0, 0), (100,40),
				   wxSL_HORIZONTAL | wxSL_LABELS )
		EVT_SLIDER(self, ID_VoiceGroupLevel, gte.onVoiceGroupLevel )
                self.voiceGroupLevelLabel = wxStaticText(self, -1, "VoiceGroup level", (0, 0))

                # check boxes
                self.recordEnableRuleChoraleIntervalSeries = wxCheckBox(self, ID_RecordEnableRuleChoraleIntervalSeries,
                                                                        "record interval series", (0,0))
		EVT_CHECKBOX(self, ID_RecordEnableRuleChoraleIntervalSeries, gte.onRecordEnableRuleChoraleIntervalSeries)

                # gauge, vu meter
		self.vuMeterLCtrl = wxGauge(self, ID_VuMeterL, 32768,(0, 0), (200,15),
				   wxGA_HORIZONTAL | wxGA_SMOOTH )
		self.vuMeterRCtrl = wxGauge(self, ID_VuMeterR, 32768,(0, 0), (200,15),
				   wxGA_HORIZONTAL | wxGA_SMOOTH )
                
                # make a Sizer to hold widgets
		siz1vgap = 15
		siz1hgap = 15
                sizer1 = wxGridBagSizer(siz1vgap, siz1hgap)
                sizer1.SetEmptyCellSize((10,10))

                
                # add the widgets to the Sizer
                
                # first column
                sizer1.Add(self.MasterLabel, (1,1))
                sizer1.Add(self.listBusChanCtrl, (3,1))
                sizer1.Add(self.tempoBpmLabel, (4,1))
                sizer1.Add(self.tempoBpmCtrl, (5,1))
                sizer1.Add(self.masterLevelLabel, (6,1))  
                sizer1.Add(self.masterLevelCtrl, (7,1))
                sizer1.Add(self.vuMeterLCtrl, (9,1))
                sizer1.Add(self.vuMeterRCtrl, (10,1))
                # second column, spacer
                sizer1.Add((0,20), (1,2))
                # third column                
                sizer1.Add(self.VoiceGroupLabel, (1,3))
                sizer1.Add(self.voiceGroupControlNumLabel, (2,3))
                sizer1.Add(self.voiceGroupControlNumCtrl, (3,3))
                sizer1.Add(self.voiceGroupStartCtrl, (4,3))
                sizer1.Add(self.voiceGroupStopCtrl, (5,3))
                sizer1.Add(self.voiceGroupLevelLabel, (6,3))
                sizer1.Add(self.voiceGroupLevelCtrl, (7,3))                
                sizer1.Add(self.voiceGroupReverbSendLabel, (9,3))
                sizer1.Add(self.voiceGroupReverbSendCtrl, (10,3))                
                # fourth column, spacer
                sizer1.Add((0,20), (1,4))
                # fifth column
                sizer1.Add(self.chorale1StartCtrl, (1,5))
                sizer1.Add(self.chorale2StartCtrl, (2,5))
                sizer1.Add(self.chorale3StartCtrl, (3,5))
                sizer1.Add(self.chorale4StartCtrl, (4,5))
                sizer1.Add(self.chorale5StartCtrl, (5,5))
                sizer1.Add(self.ruleChoraleIntervalSeriesLabel, (7,5))
                sizer1.Add(self.ruleChoraleVoiceRangeLabel, (8,5))
                sizer1.Add(self.ruleChoraleHarmonicIntervalSetLabel, (9,5))
                sizer1.Add(self.ruleChoraleHarmonicScoreWeightLabel, (10,5))
                sizer1.Add(self.ruleChoraleMutationTypeScoresLabel, (11,5))
                sizer1.Add(self.ruleChoraleChangeMutationTypeScoreLabel, (12,5))
                #sixth column
                sizer1.Add(self.chorale1StopCtrl, (1,6))
                sizer1.Add(self.chorale2StopCtrl, (2,6))
                sizer1.Add(self.chorale3StopCtrl, (3,6))
                sizer1.Add(self.chorale4StopCtrl, (4,6))
                sizer1.Add(self.chorale5StopCtrl, (5,6))
                sizer1.Add(self.ruleChoraleIntervalSeriesCtrl, (7,6))
                sizer1.Add(self.ruleChoraleVoiceRangeCtrl, (8,6))
                sizer1.Add(self.ruleChoraleHarmonicIntervalSetCtrl, (9,6))
                sizer1.Add(self.ruleChoraleHarmonicScoreWeightCtrl, (10,6))
                sizer1.Add(self.ruleChoraleMutationTypeScoresCtrl, (11,6))
                sizer1.Add(self.ruleChoraleChangeMutationTypeScoreCtrl, (12,6))
                # seventh column
                sizer1.Add(self.recordEnableRuleChoraleIntervalSeries, (7,7))
                # right column spacer
                sizer1.Add((0,0), (13,8))
                
                # set the size of the parent window1
                # to fit the space needed for the sizer
                sizer1.SetSizeHints(parent)
                self.SetSizer(sizer1)
                self.SetAutoLayout(1)
                self.Layout()

	# Methods of the ControlPanel class.
	# These are used only for updateing the GUI with values generated elsewhere in the application
	# the action functions associated with the GUI can be found guiTriggeredEvents
                            
        def updateRuleChoraleIntervalSeries(self, value):
            # update the value in GUI textbox
            self.ruleChoraleIntervalSeriesCtrl.Clear()
            self.ruleChoraleIntervalSeriesCtrl.WriteText('%s'%value)                            

        def updateVuMeters(self, rms1, rms2):
            # update the value displayed by the gauge widgets used as VU meters
            self.vuMeterLCtrl.SetValue(rms1)
            self.vuMeterRCtrl.SetValue(rms2)
        
def test():
    '''
    self test
    '''
    ctrl_app = wxPySimpleApp()
    frame = wxFrame( None, -1, "Csound Controller" )
    ctrl_panel = ControlPanel( frame )
    frame.Show(True)
    ctrl_app.MainLoop()

if __name__ == '__main__':
    test()
