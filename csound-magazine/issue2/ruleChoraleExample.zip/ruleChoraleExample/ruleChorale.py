# This is a melody generator
# It takes a list of intervals and generates a melody
# by adding the interval to a "currentNote".
# If the melody range exceeds high or low limits for the range,
# the selected interval is inverted as this may help getting the melody back in range
## (aditional measures for range control should be implemented)
# It also has some rules for harmony when more than one voice plays simultaneously.
# The rules takes into account already sounding notes in other voices,
# and uses a set of "preferred harmony intervals", which is in essence a weighted list of all intervals within an octave.
# The melodic interval series is also weighted, so that there is a bias towards playing the interval series as is,
# and if that is not possible, try to invert or reverse the series.
# The harmony interval score and the melody interval score are summed,
# and the candidate with the highest score is used as the next note.
# Oeyvind Brandtsegg 2005 - obrandts@online.no

import copy
import random
import listOperations

class IntervalMelody:
    '''
    Generate a simple melody line based on a series of intervals
    '''

    def __init__(self):
        self.intervalSeries = [1,4,-1,-2] # melodic interval series
#        self.intervalSeries = [1,5,7,10] # melodic interval series
        self.hiLimit = 84
        self.lowLimit = 48
        self.rhythmSeries = [1,1,1,1,2,2,4]
        self.rhythmSeriesUse = []
        self.pitchClassesInUse = [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1] # can use up to ten voices, expandable
        self.harmonicIntervalScore = [[0, 0], # format of :interval, score
                                      [1, 1], # minor second
                                      [2, 1], # major second
                                      [3, 4], # minor third
                                      [4, 4], # major third
                                      [5, 3], # etc
                                      [6, 0],
                                      [7, 3],
                                      [8, 4],
                                      [9, 4],
                                      [10, 1],
                                      [11, 1]]
        self.harmonicScoreWeight = 1    # how much emphasis is placed on harmonic relations in comparision to melodic relation (firmness of melodic interval series)

        self.seriesNormalScore = 4  # score for following the series in normal order
        self.seriesReverseScore = 3 # score for reversing the intervals in the series
        self.seriesInverseScore = 2 # score for inverting the intervals in the series
        self.seriesRevInvScore = 1  # score for reversing and inverting the intervals in the series
        self.changeMutationScore = -1 # penalty for changing the mutation, e.g. from normal to inverse or vice versa
            
    def nextNote(self, voice, basePitch, mutationType='normalMutation', seriesIndex=-1):
        '''
        Generate pitch and delta time for the next note in the melody
        '''

        # get the interval series
        intervalSeries = copy.copy(self.intervalSeries)

        # rotate the interval series one more step than the previous seriesIndex
        seriesIndex = (seriesIndex+1)%len(intervalSeries)
        listOperations.listRotate(intervalSeries, seriesIndex)

        # generate all melodic valid candidates, with score.
        # this is a list of size 4*2 (interval, score)
        melodicCandidates = self.generateIntervalCandidates(intervalSeries, mutationType)
        # generate all harmonic valid candidates, with score.
        # this is a list of size 12*2 (interval, score)
        harmonicCandidates = self.generateHarmonicCandidates(basePitch, voice)
        # for tuning scores
#        print 'melodic', melodicCandidates, 'harmonic', harmonicCandidates

        # sum scores and select (sum those intervals that is found in both lists, leave others untouched)
        scoreList = []
        for hCandidate in harmonicCandidates:
            for mCandidate in melodicCandidates:
                if hCandidate[0] == mCandidate[0]:
                    hCandidate[1] += mCandidate[1]
            scoreList.append(hCandidate[1])
        # select the one with highest score, collect into list if more than one with equal score
        highScore = max(scoreList)
        selectCandidates = []
        for hCandidate in harmonicCandidates:
            if hCandidate[1] == highScore:
                selectCandidates.append(hCandidate)
        # print 'number of equal candidates ', len(selectCandidates), selectCandidates, harmonicCandidates
        selectCandidate = selectCandidates[0][0] # pick the first one, and leave only the interval (discard score)
            
        pitch = basePitch + selectCandidate
        #print 'pitch', pitch, basePitch
        # range control
        invertedFlag = 1
        if pitch > self.hiLimit and selectCandidate > 0:
            pitch = basePitch - selectCandidate
            invertedFlag = -1
        if pitch < self.lowLimit and selectCandidate < 0:
            pitch = basePitch - selectCandidate
            invertedFlag = -1
        #print 'after range pitch', pitch, basePitch

        # check what mutation of the intervalSeries the selected interval can be found in
        # return the mutationType used, so that the voice will try to continue on the last used mutation of the series
        selectCandidate *= invertedFlag
        if selectCandidate == melodicCandidates[0][0]:
            if mutationType != 'normalMutation':
                print 'mutationType Changed to Normal'
            mutationType = 'normalMutation'
        elif selectCandidate == melodicCandidates[1][0]:
            if mutationType != 'reverseMutation':
                print 'mutationType Changed to Reverse'
            mutationType = 'reverseMutation'
        elif selectCandidate == melodicCandidates[2][0]:
            if mutationType != 'inverseMutation':
                print 'mutationType Changed to Inverse'
            mutationType = 'inverseMutation'
        elif selectCandidate == melodicCandidates[3][0]:
            if mutationType != 'revinvMutation':
                print 'mutationType Changed to RevInv'

            mutationType = 'revinvMutation'
        else:
            print '%d does not belong in interval series'%selectCandidate, ', voice', voice, 'will use %s for next note'%mutationType
        
        delta =  self.generateRhythm()
        # update pitchclasses in use
        self.pitchClassesInUse[voice] = pitch%12
        return (pitch, mutationType, seriesIndex, delta)
        
    def generatePitch(self, basePitch, intervalSeries):
        '''
        Generate the next pitch based on the interval series
        '''
        interval = intervalSeries.pop(0)
        if (basePitch + interval > self.hiLimit or
            basePitch + interval < self.lowLimit):
            print 'inverse series'
            intervalSeries = self.invertIntervals(intervalSeries)
        return [basePitch + interval, intervalSeries]

    def generateIntervalCandidates(self, intervalSeries, mutationType):
        '''
        Generate intervalCandidates based on the interval series,
        give each interval a score
        '''
        # Sum the mutation type scores with the (negative) score for changing mutation.
        # As the input argument mutationType refers to the previous mutation type used,
        # the self.changeMutationScore affects the tendency to stick to the same mutationType
        # as the previous note in the series had used.
        normalScore = self.seriesNormalScore
        reverseScore = self.seriesReverseScore
        inverseScore = self.seriesInverseScore
        revinvScore = self.seriesRevInvScore
        if mutationType == 'normalMutation':
            normalScore -=  self.changeMutationScore
        if mutationType == 'reverseMutation':
            reverseScore -=  self.changeMutationScore
        if mutationType == 'inverseMutation':
            inverseScore -=  self.changeMutationScore
        if mutationType == 'revinvMutation':
            revinvScore -=  self.changeMutationScore
            
        iNormal = intervalSeries[0] # normal
        iReverse = intervalSeries[-1] # reverse
        iInverse = - iNormal # inverse    
        iRevInv = - iReverse # reverse and inverse
        intervalCandidates = [[iNormal, normalScore],
                              [iReverse, reverseScore],
                              [iInverse, inverseScore],
                              [iRevInv, revinvScore]]
        return intervalCandidates

    def generateHarmonicCandidates(self, basePitch, voice):
        '''
        Generate candidates for the interval from the current note (basePitch)
        to other simultaneous pitches. All possible intervals within an octave range are returned
        with a score based on how the next note will relate harmonically to all other sounding notes
        '''
        voiceNum = 1
        # list to keep track of the score for each interval
        harmonyScoreList = [
            [-12,0],[-11,0],[-10,0],[-9,0],[-8,0],[-7,0],[-6,0],[-5,0],[-4,0],[-3,0],[-2,0],[-1,0],
            [0,0],[1,0],[2,0],[3,0],[4,0],[5,0],[6,0],[7,0],[8,0],[9,0],[10,0],[11,0], [12,0]]
        for pc in self.pitchClassesInUse:
            if pc == -1:   # if pitchclass not in use, skip
                continue
            #if voice == voiceNum:   # dont't check interval from itself
            #    continue
            voiceNum += 1
            for interval in range(-12,13):
                harmony = ((basePitch+interval) - pc)%12
                ### look up interval*2 in self.harmonicIntervalScore to find score for this harmony
                harmonyScore = self.harmonicIntervalScore[harmony][1] 
                ###write interval and score to new list and return this list
                harmonyScoreList[interval][1] += harmonyScore
        # divide by number of voices processed, and scale by self.harmonicScoreWeight
        for item in harmonyScoreList:
            item[1] *= self.harmonicScoreWeight/float(voiceNum)
        return harmonyScoreList


    def generateRhythm(self):
        '''
        Very simple rhythm generator. Takes a list of delta time factors,
        choose one randomly and remove it from the list
        '''
        if self.rhythmSeriesUse == []:
            self.rhythmSeriesUse = copy.copy(self.rhythmSeries)
        choose = random.randint(0, len(self.rhythmSeriesUse)-1)    
        delta = self.rhythmSeriesUse.pop(choose)
        return delta

    def invertIntervals(self, alist):
        '''
        Melodic interval inversion, +1 becomes -1 and so on
        '''
        for i in range(0, len(alist)):
            alist[i] = - alist[i]
        return alist


