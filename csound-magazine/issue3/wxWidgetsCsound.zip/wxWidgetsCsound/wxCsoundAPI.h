#ifndef MYFRAME_H
#define MYFRAME_H
#include <wx/wx.h>
#include <csound.h>
//--------------------------------------------------------------------------
struct userData{
/*result of csoundCompile()*/
int result; 
/*instance of csound*/
CSOUND* csound; 
/*performance status*/
bool PERF_STATUS; 
};
//--------------------------------------------------------------------------
//main csound performance thread.... 
uintptr_t csThread(void *clientData);
//--------------------------------------------------------------------------
enum
{
ID_Quit = 100,
ID_About = 200,
ID_Scroll = 300,
ID_Open = 400,
ID_Play = 500,
ID_Timer = 600
}; 
//--------------------------------------------------------------------------
class MyApp: public wxApp
{
    virtual bool OnInit();
};
//--------------------------------------------------------------------------
class MyFrame: public wxFrame
{
public:
    MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
    ~MyFrame();
    void OnQuit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);
    void OnOpen(wxCommandEvent& event);
    void ScrollChange(wxScrollEvent &event);
    void OnPlay(wxCommandEvent &event);
    void OnTimer(wxTimerEvent& event);
    wxMenu *menu;
    wxMenuBar *menuBar;
    wxSlider* slider;
    wxButton* button;
    wxPanel* panel;
    userData* ud;
    wxTextCtrl* label;
    wxTimer* timer;
    char** cmdl;
    void* threadID;
  protected:
    DECLARE_EVENT_TABLE()
};
//--------------------------------------------------------------------------
#endif
