#include "wxCsoundAPI.h"

IMPLEMENT_APP(MyApp)
//--------------------------------------------------------------------------
bool MyApp::OnInit()
{
    MyFrame *frame = new MyFrame( "Soundfiler..", wxPoint(50,50), wxSize(220,120) );
    frame->Show(TRUE);
    return TRUE;
} 
//--------------------------------------------------------------------------
BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(ID_Open, MyFrame::OnOpen)
    EVT_MENU(ID_Quit, MyFrame::OnQuit)
    EVT_MENU(ID_About, MyFrame::OnAbout)
    EVT_BUTTON(ID_Play, MyFrame::OnPlay)
    EVT_COMMAND_SCROLL_THUMBTRACK ( ID_Scroll, MyFrame::ScrollChange)
    EVT_TIMER(ID_Timer, MyFrame::OnTimer)
END_EVENT_TABLE()
//--------------------------------------------------------------------------
MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
    menu = new wxMenu;
    menu->Append( ID_Open, "&Open" );
    menu->Append( ID_About, "&About..." );
    menu->Append( ID_Quit, "E&xit" );
    menuBar = new wxMenuBar;
    menuBar->Append( menu, "&File" );
    wxFrame::SetMenuBar( menuBar );
    panel = new wxPanel(this, -1, wxPoint(0, 0), wxFrame::GetSize());
    slider = new wxSlider(panel, ID_Scroll, 0, 0, 100, wxPoint(10, 5), wxSize(200, 30));
    button = new wxButton(panel, ID_Play, "Play file", wxPoint(140, 40), wxSize(60, 20));
    label = new wxTextCtrl(panel, -2, "0:00:00", wxPoint(15, 40), wxSize(50, 20), wxTE_RICH);
    ud = (userData *) malloc(sizeof(userData));
    timer = new wxTimer(this, ID_Timer); 
    //initialise PERF_STATUS to 0
    ud->PERF_STATUS = 0;
}
//--------------------------------------------------------------------------
MyFrame::~MyFrame()
{
csoundDestroy(ud->csound);
delete ud;
delete cmdl;
}
//--------------------------------------------------------------------------
void MyFrame::OnQuit(wxCommandEvent& event)
{
    wxMessageBox("Add test here to make sure Csound has stopped performing...");
    Close(TRUE);
}
//--------------------------------------------------------------------------
void MyFrame::OnAbout(wxCommandEvent& event)
{
    wxMessageBox("A simple Csound application");
}
//--------------------------------------------------------------------------
void MyFrame::OnOpen(wxCommandEvent& event)
{
 if(!ud->PERF_STATUS){
 /*char array to hld command line flags*/
 /*allocate enough memory to hold 
 three command line parameters*/
 cmdl = (char **) malloc(sizeof(char*)*(3));
 /*call wxFileDialog constructor*/
 wxFileDialog *dlg = new wxFileDialog(this, "Open a text file", "", "", 
                                       "All files(*.*)|*.*|Text Files(*.txt)|*.txt", 
                                       wxOPEN, wxDefaultPosition);
  /* only enter test if user presses Ok if the user were
  to press cancel instead ShowModal() would return wxID_CANCEL*/                                    
  if ( dlg->ShowModal() == wxID_OK )
  {
  /*get file name, GetPath retrieves name and path of 
  selected file and append --strset to the start of it*/
  wxString filestring =  "--strset1="+dlg->GetPath();
  /*create instance of Csound*/
  ud->csound=csoundCreate(NULL);
  /*set command line flags*/
  cmdl[0] = "csound";
  cmdl[1] = "soundfile.csd";
  cmdl[2] = (char*)filestring.ToAscii();
  
  /*make sure the last thread has finished 
  and reset csound
  csoundJoinThread(threadID);
  csoundReset(ud->csound);*/  
  ud->result=csoundCompile(ud->csound,3,cmdl);
  }
  dlg->Destroy();   
  }
  else wxMessageBox("Please stop the audio first");
}
//--------------------------------------------------------------------------
void MyFrame::OnPlay(wxCommandEvent& event)
{
if(!ud->result)
 { 
 MYFLT* pvalue;
 if(ud->PERF_STATUS==0)
   {
      ud->PERF_STATUS=1;
      threadID = csoundCreateThread(csThread, (void*)ud);
      /*sleep for a few milliseconds to ensure the thread has
      adequte time to start before retrieving value of "lenght*/
      Sleep(100);
      timer->Start(300);
      if(csoundGetChannelPtr(ud->csound, &pvalue, "length", CSOUND_OUTPUT_CHANNEL | CSOUND_CONTROL_CHANNEL)==0)
         {
         /*set range according to sound file lenght*/            
         slider->SetRange(0, (int)*pvalue); 
         }      
      button->SetLabel("Pause");
      }
else{
    timer->Stop();       
    ud->PERF_STATUS = 0;  
    button->SetLabel("Play");  
    }
}
else wxMessageBox("please open an audio file");
}
//--------------------------------------------------------------------------
void MyFrame::ScrollChange(wxScrollEvent& event)
{
 if(ud->PERF_STATUS==1)
   {
    MYFLT* pvalue; 
    //send position of slider to Csound on channel "skip"
    if(csoundGetChannelPtr(ud->csound, &pvalue, "skip",
    CSOUND_INPUT_CHANNEL | CSOUND_CONTROL_CHANNEL)==0)
   *pvalue = (MYFLT)slider->GetValue();
   } 
}  
//--------------------------------------------------------------------------
void MyFrame::OnTimer(wxTimerEvent& event)
{
 if(ud->PERF_STATUS==1)
   {
   MYFLT* pvalue;
   int scoreTime; 
   wxString minCaption, secCaption;
   if(csoundGetChannelPtr(ud->csound, &pvalue, "time", CSOUND_OUTPUT_CHANNEL | CSOUND_CONTROL_CHANNEL)==0)
     {          
     scoreTime = (int)*pvalue; 
     }
   slider->SetValue(scoreTime);
   int seconds = ((int)scoreTime)%60;
   int minutes = (int)((scoreTime)/60);
   //pass times to strings...
   minCaption.Printf("%d", minutes);
   secCaption.Printf("%d", seconds); 
   if((seconds<10)&&(minutes<10))                            
   label->SetValue("0:0"+minCaption+":0"+secCaption);
   else if((seconds>9)&&(minutes<10))
   label->SetValue("0:0"+minCaption+":"+secCaption);
   else if((seconds<10)&&(minutes>9))
   label->SetValue("0:"+minCaption+":0"+secCaption);
   else label->SetValue("0:"+minCaption+":"+secCaption);
   }
else
    {
      slider->SetValue(0);
      label->SetValue("0:00:00");
      csoundJoinThread(ud->csound);
      csoundReset(ud->csound);
      ud->result=csoundCompile(ud->csound,3,cmdl);
      button->SetLabel("Play"); 
      timer->Stop();
    }
}
//--------------------------------------------------------------------------
uintptr_t csThread(void *data)
{
userData* udata = (userData*)data;
if(!udata->result)
   {
   while((csoundPerformKsmps(udata->csound) == 0)&&(udata->PERF_STATUS==1));
   }
   udata->PERF_STATUS=0;
return 1;
}

