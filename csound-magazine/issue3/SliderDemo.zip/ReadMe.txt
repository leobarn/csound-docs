PC.
1.) Csound needs to be in your path, working, and able to run from command prompt.
	ControlPanel/System/Advanced/EnvironmentVariables/Path

	also set OPCODEDIR, if needed.


2.) The path to the SliderDemo.csd needs to be set manually in SliderDemo.java
by typing it in the args.Append() method.


3.) SliderDemo.java needs to be compiled with the csnd.jar, and uses the SliderDemo.csd,
	and javac needs to know where to find them.

	You could write a batch file to set the path to those items.
	Ex.  (adjust for your folders, and save in a file called xxx.bat, then 
		run the .bat from command prompt before running javac).
	
	set PATH=C:\Program Files\Java\jdk1.5.0_02\bin;%PATH%
	set JAVA_HOME=C:\Program Files\Java\jdk1.5.0_02


	set CLASSPATH=.;C:\eclipse\workspace_J_Csound\csnd.jar;C:\eclipse\workspace_J_Csound\SliderDemo;

4.) compile the app from the command prompt by typing javac SliderDemo.java

5.) run the app by from the command prompt by typing java SliderDemo


The sound runs for 20 secs (f0 statement in the score), during which you
can adjust the slider to change the pitch.