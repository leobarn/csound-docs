--------------
PC

Unzip the BPFdemo.zip and place the contents in Pd's bin directory.

The BPFdemo.pd patch requires a working Csound and Pure Data on your machine.

If you know the csoundapi~ Pd object for Csound is working,
then the break point function patch should also work.

The csoundapi~ library from your Csound5 distribution (csoundapi~.dll) should be placed
in Pd's bin directory along with your .csd and any other files it requires.

See the instructions for how to get the csoundapi~ library working in Pd if you
do not have it working already.

Also Victor Lazzarini has a page with a bit more information at:
<<http://music.nuim.ie//musictec/csound/>>>

On PC, Pd is usually called from the command line, using the csoundapi~ library.

Ex. >pd -lib csoundapi~

Use the File/Open menu to navigate to the bin directory and open the BPFdemo.pd
------------
Mac

I don't know anything about Pd on Intel yet, so check the Pd wiki <<http://puredata.info/>>
if having problems with that.

On PPC Mac OSX, the csoundapi~ darwin is usually placed in Library/frameworks/CsoundLib.framework/Versions/5.1/Resources/PD when Csound is installed along with a help-csoundapi~.pd file.

I've always struggled with Pd and the csoundapi~ on Mac.  

I've had some success placing the help-csoundapi~.pd and .csd file in Library/Documentation/Csound for some reason.  

Also the mac likes to have full paths to files so you might also try that too on the csoundapi~ object in the patch. Ex. "/Users/yourmachine/Library/etc/etc" if placing the files in the Library/Documentation/Csound folder does not work.

Finally you can ask some of the Mac experts on the Csound list <csound-help@lists.bath.ac.uk> who also use Pd since anything I do on Mac is a kluge and not to be considered offical.



