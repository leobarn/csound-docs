#!/usr/bin/perl
use strict;

my $foo = "Csound";
my $bar = "5.04";

print "Have you upgraded to $foo version $bar, yet?\n"

