#!/usr/bin/perl
use strict;

my $sine = 1;
print "a1 oscil 10000, 440, $sine" . "\n";
print 'a2 oscil 10000, 444, $sine' . "\n";

